// IR0NI v14.5 - configure antes de distribuir aos clientes.
// Exemplo: https://api.seudominio.com
globalThis.IR0NI_CONFIG = Object.freeze({
  serverUrl: 'https://ir0ni-api-production.up.railway.app',
  onlineGraceHours: 6,
  heartbeatMinutes: 1
});
