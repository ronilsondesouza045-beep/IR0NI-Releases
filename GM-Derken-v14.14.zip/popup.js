const indicator = document.getElementById('indicator');
const details = document.getElementById('details');

IR0NILicense.getState().then(state => {
  const plan = document.getElementById('popup-plan');
  const id = document.getElementById('popup-install-id');
  plan.textContent = state.valid ? 'PRO ATIVO' : 'FREE';
  plan.classList.toggle('pro', state.valid);
  id.textContent = state.installId;
}).catch(() => {});
chrome.storage.local.get('panelArtDataUrl').then(saved => {
  const dataUrl = saved.panelArtDataUrl;
  if (typeof dataUrl === 'string' && /^data:image\/(?:jpeg|png|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(dataUrl)) {
    document.body.style.setProperty('--panel-art', `url("${dataUrl}")`);
    document.body.classList.add('has-panel-art');
  }
}).catch(() => {});

function show(message, detail, state) {
  indicator.textContent = message;
  indicator.className = `indicator ${state}`;
  details.textContent = detail;
}

function inspectFacebookPage() {
  const loginForm = document.querySelector('input[name="email"]') &&
    document.querySelector('input[name="pass"]');
  const onLoginPage = /^\/(login|checkpoint)(\/|$)/i.test(location.pathname);
  const groupsLink = document.querySelector('a[href="/groups/"], a[href^="https://www.facebook.com/groups/"]');
  const homeLink = document.querySelector('a[aria-label="Página inicial"], a[aria-label="Home"]');
  return {
    needsLogin: Boolean(loginForm || onLoginPage),
    appearsSignedIn: Boolean(!loginForm && !onLoginPage && (groupsLink || homeLink)),
    pageTitle: document.title.slice(0, 120)
  };
}

async function check() {
  show('Procurando aba do Facebook...', 'Verificando as abas deste Chrome.', 'wait');
  try {
    const tabs = await chrome.tabs.query({url: ['https://facebook.com/*', 'https://*.facebook.com/*']});
    const tab = tabs.find(item => item.active) || tabs.find(item => /^https:\/\/(www\.)?facebook\.com\//.test(item.url || ''));
    if (!tab?.id) {
      show('Facebook não encontrado', 'Abra facebook.com neste perfil do Chrome e tente novamente.', 'wait');
      return;
    }
    const results = await chrome.scripting.executeScript({target: {tabId: tab.id}, func: inspectFacebookPage});
    const state = results[0]?.result;
    if (state?.needsLogin) {
      show('Login necessário nesta aba', 'Entre na conta diretamente no Facebook e verifique novamente.', 'bad');
    } else if (state?.appearsSignedIn) {
      show('Facebook aberto e conectado', 'Esta é a sessão do Chrome em que a extensão está instalada. Confira sua conta na aba.', 'good');
    } else {
      show('Aba do Facebook encontrada', 'A página ainda está carregando ou a interface mudou. Confira a conta na aba.', 'wait');
    }
  } catch (error) {
    show('Não consegui verificar a aba', String(error.message || error), 'bad');
  }
}

document.getElementById('check').addEventListener('click', check);
document.getElementById('open').addEventListener('click', async () => {
  await chrome.tabs.create({url: 'https://www.facebook.com/'});
  window.close();
});

const groupField = document.getElementById('group');
const postField = document.getElementById('post');
const resultLine = document.getElementById('draft-result');
chrome.storage.session.get(['group', 'post']).then(saved => {
  groupField.value = saved.group || '';
  postField.value = saved.post || '';
});

for (const field of [groupField, postField]) {
  field.addEventListener('input', () => {
    chrome.storage.session.set({group: groupField.value, post: postField.value});
  });
}

function groupUrl(value) {
  const raw = value.trim();
  if (/^[A-Za-z0-9_.-]+$/.test(raw)) {
    return `https://www.facebook.com/groups/${encodeURIComponent(raw)}/`;
  }
  try {
    const url = new URL(raw.startsWith('http') ? raw : `https://${raw}`);
    const parts = url.pathname.split('/').filter(Boolean);
    if (!['facebook.com', 'www.facebook.com'].includes(url.hostname) ||
        parts[0] !== 'groups' || !/^[A-Za-z0-9_.-]+$/.test(parts[1] || '') ||
        ['feed', 'joins', 'discover', 'create'].includes(parts[1].toLowerCase())) {
      return null;
    }
    return `https://www.facebook.com/groups/${encodeURIComponent(parts[1])}/`;
  } catch {
    return null;
  }
}

document.getElementById('go-group').addEventListener('click', async () => {
  const url = groupUrl(groupField.value);
  if (!url) {
    resultLine.textContent = 'Informe um link ou ID válido de grupo.';
    return;
  }
  await chrome.storage.session.set({group: groupField.value, post: postField.value});
  await chrome.tabs.create({url});
  window.close();
});

async function runDraft(publish) {
  const post = postField.value.trim();
  if (!post) {
    resultLine.textContent = 'Escreva o texto antes de continuar.';
    return;
  }
  const button = document.getElementById(publish ? 'publish' : 'prepare');
  button.disabled = true;
  resultLine.textContent = publish ? 'Preparando e publicando neste grupo...' : 'Preparando no grupo aberto...';
  try {
    await chrome.storage.session.set({group: groupField.value, post: postField.value});
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    if (!tab?.id || !/^https:\/\/(www\.)?facebook\.com\/groups\/[^/]+/.test(tab.url || '')) {
      resultLine.textContent = 'Deixe a página de um grupo aberta nesta aba.';
      return;
    }
    const result = await chrome.scripting.executeScript({
      target: {tabId: tab.id}, func: prepareDraft, args: [post, publish]
    });
    resultLine.textContent = result[0]?.result?.message || result[0]?.result || 'Confira a página do grupo.';
  } catch (error) {
    resultLine.textContent = `Falha: ${String(error.message || error)}`;
  } finally {
    button.disabled = false;
  }
}

document.getElementById('prepare').addEventListener('click', () => runDraft(false));
document.getElementById('publish').addEventListener('click', () => runDraft(true));
document.getElementById('batch').addEventListener('click', async () => {
  const url = chrome.runtime.getURL('queue.html');
  const existing = (await chrome.tabs.query({url}))[0];
  if (existing?.id) {
    await chrome.tabs.update(existing.id, {active: true});
    await chrome.windows.update(existing.windowId, {focused: true});
  } else {
    await chrome.windows.create({url, type: 'popup', width: 1120, height: 850});
  }
  window.close();
});
check();


async function refreshOnlinePopup() {
  const dot =
    document.getElementById('popup-server-dot');

  const line =
    document.getElementById('popup-server');

  const state =
    await IR0NIOnline.getState();

  const configured =
    Boolean(IR0NIOnline.serverUrl());

  dot.className =
    'server-dot ' +
    (state.connected ? 'online' : 'offline');

  line.textContent =
    state.connected
      ? `Servidor GM Derken conectado · ${state.plan || 'FREE'}`
      : (
          configured
            ? `Servidor GM Derken offline · ${state.reason || 'conecte'}`
            : 'Servidor GM Derken ainda não configurado'
        );
}

document
  .getElementById('popup-connect')
  .addEventListener(
    'click',
    async () => {
      const btn =
        document.getElementById('popup-connect');

      btn.disabled = true;
      btn.textContent = 'Conectando...';

      const result =
        await IR0NIOnline.connect();

      btn.disabled = false;
      btn.textContent = 'Conectar';

      if (!result?.ok) {
        details.textContent =
          result?.reason ||
          'Não foi possível conectar ao servidor.';
      }

      await refreshOnlinePopup();
    }
  );

IR0NIOnline
  .heartbeat()
  .catch(() => null)
  .finally(
    () =>
      refreshOnlinePopup()
        .catch(() => {})
  );
