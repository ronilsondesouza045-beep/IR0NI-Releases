﻿$ErrorActionPreference = "Stop"

$HelperVersion = "1.0.0"
$ConfigPath = Join-Path $PSScriptRoot "config.json"
$PidPath = Join-Path $PSScriptRoot "updater.pid"
$BackupDir = Join-Path $PSScriptRoot "Backups"

function Write-Utf8 {
    param(
        [string]$Path,
        [string]$Text
    )

    $Encoding =
        New-Object System.Text.UTF8Encoding($false)

    [System.IO.File]::WriteAllText(
        $Path,
        $Text,
        $Encoding
    )
}

function Normalize-Version {
    param([string]$Value)

    $Text =
        [string]$Value

    $Text =
        $Text.Trim() -replace '^[vV]', ''

    $Parts =
        $Text.Split('.')

    if(
        $Parts.Count -ge 3 -and
        $Parts[0] -eq '0'
    ) {
        $Text =
            ($Parts[1..($Parts.Count-1)] -join '.')
    }

    try {
        return [Version]$Text
    }
    catch {
        return [Version]'0.0'
    }
}

function Get-ManifestVersion {
    param([string]$ExtensionPath)

    $ManifestPath =
        Join-Path $ExtensionPath "manifest.json"

    if(-not (Test-Path $ManifestPath)) {
        throw "manifest.json não encontrado."
    }

    $Manifest =
        Get-Content $ManifestPath -Raw |
        ConvertFrom-Json

    return [string]$Manifest.version
}

function Write-RuntimeState {
    param(
        [string]$ExtensionPath,
        [string]$Status,
        [string]$Message,
        [string]$CurrentVersion,
        [string]$InstalledVersion = ""
    )

    $State = [ordered]@{
        helper_version    = $HelperVersion
        status            = $Status
        last_check        = (Get-Date).ToUniversalTime().ToString("o")
        current_version   = $CurrentVersion
        installed_version = $InstalledVersion
        message           = $Message
    }

    $StatePath =
        Join-Path $ExtensionPath "updater-runtime.json"

    Write-Utf8 `
        $StatePath `
        ($State | ConvertTo-Json -Depth 10)
}

function Assert-ReleaseUrl {
    param(
        [string]$Url,
        [string]$ExpectedPrefix
    )

    if(-not $Url) {
        throw "URL da Release ausente."
    }

    $Uri =
        [Uri]$Url

    if(
        $Uri.Scheme -ne 'https' -or
        $Uri.Host -ne 'github.com'
    ) {
        throw "Origem de atualização não autorizada."
    }

    if(
        -not $Uri.AbsolutePath.StartsWith(
            $ExpectedPrefix,
            [StringComparison]::OrdinalIgnoreCase
        )
    ) {
        throw "Release não pertence ao repositório autorizado."
    }
}

function New-Backup {
    param(
        [string]$ExtensionPath
    )

    New-Item `
        -ItemType Directory `
        -Force `
        -Path $BackupDir |
        Out-Null

    $Stamp =
        Get-Date -Format "yyyyMMdd-HHmmss"

    $Stage =
        Join-Path `
            $env:TEMP `
            "GM-Derken-Backup-$Stamp"

    $Zip =
        Join-Path `
            $BackupDir `
            "GM-Derken-$Stamp.zip"

    if(Test-Path $Stage) {
        Remove-Item $Stage -Recurse -Force
    }

    New-Item `
        -ItemType Directory `
        -Force `
        -Path $Stage |
        Out-Null

    & robocopy `
        $ExtensionPath `
        $Stage `
        /E `
        /R:1 `
        /W:1 `
        /NFL `
        /NDL `
        /NJH `
        /NJS `
        /NP `
        /XD `
        ".git" `
        "node_modules" `
        "_BACKUPS" `
        /XF `
        "updater-runtime.json" |
        Out-Null

    $RoboCode =
        $LASTEXITCODE

    if($RoboCode -gt 7) {
        throw "Falha criando backup local. Robocopy: $RoboCode"
    }

    Compress-Archive `
        -Path "$Stage\*" `
        -DestinationPath $Zip `
        -CompressionLevel Optimal `
        -Force

    Remove-Item `
        $Stage `
        -Recurse `
        -Force

    $Old =
        Get-ChildItem `
            $BackupDir `
            -Filter "GM-Derken-*.zip" `
            -File |
        Sort-Object LastWriteTime -Descending |
        Select-Object -Skip 3

    foreach($File in $Old) {
        Remove-Item $File.FullName -Force
    }

    return $Zip
}

function Apply-Update {
    param(
        [string]$ExtensionPath,
        [string]$LatestVersion,
        [string]$DownloadUrl,
        [string]$ShaUrl,
        [string]$ExpectedPrefix
    )

    Assert-ReleaseUrl `
        -Url $DownloadUrl `
        -ExpectedPrefix $ExpectedPrefix

    Assert-ReleaseUrl `
        -Url $ShaUrl `
        -ExpectedPrefix $ExpectedPrefix

    $Work =
        Join-Path `
            $env:TEMP `
            ("GM-Derken-Update-" + [guid]::NewGuid().ToString("N"))

    $Stage =
        Join-Path $Work "stage"

    $Zip =
        Join-Path $Work "release.zip"

    $Sha =
        Join-Path $Work "sha256.txt"

    New-Item `
        -ItemType Directory `
        -Force `
        -Path $Stage |
        Out-Null

    try {
        Invoke-WebRequest `
            -Uri $DownloadUrl `
            -OutFile $Zip `
            -UseBasicParsing

        Invoke-WebRequest `
            -Uri $ShaUrl `
            -OutFile $Sha `
            -UseBasicParsing

        $ShaText =
            Get-Content $Sha -Raw

        $Match =
            [regex]::Match(
                $ShaText,
                '(?i)\b[a-f0-9]{64}\b'
            )

        if(-not $Match.Success) {
            throw "SHA256 esperado não encontrado."
        }

        $ExpectedHash =
            $Match.Value.ToUpperInvariant()

        $ActualHash =
            (Get-FileHash `
                $Zip `
                -Algorithm SHA256
            ).Hash.ToUpperInvariant()

        if($ExpectedHash -ne $ActualHash) {
            throw "SHA256 da atualização não confere."
        }

        Expand-Archive `
            -Path $Zip `
            -DestinationPath $Stage `
            -Force

        $NewManifestPath =
            Join-Path $Stage "manifest.json"

        if(-not (Test-Path $NewManifestPath)) {
            throw "A Release não contém manifest.json."
        }

        $NewManifest =
            Get-Content $NewManifestPath -Raw |
            ConvertFrom-Json

        $ExpectedVersion =
            Normalize-Version $LatestVersion

        $ManifestVersion =
            Normalize-Version ([string]$NewManifest.version)

        if($ExpectedVersion -ne $ManifestVersion) {
            throw "A versão do manifest não corresponde à Release."
        }

        $Backup =
            New-Backup `
                -ExtensionPath $ExtensionPath

        try {
            Get-ChildItem `
                -LiteralPath $Stage `
                -Force |
            ForEach-Object {
                Copy-Item `
                    -LiteralPath $_.FullName `
                    -Destination $ExtensionPath `
                    -Recurse `
                    -Force
            }

            $BundledHelper =
                Join-Path `
                    $ExtensionPath `
                    "updater\GM-Derken-Updater.ps1"

            if(Test-Path $BundledHelper) {
                Copy-Item `
                    -LiteralPath $BundledHelper `
                    -Destination $PSCommandPath `
                    -Force
            }
        }
        catch {
            $Restore =
                Join-Path `
                    $env:TEMP `
                    ("GM-Derken-Restore-" + [guid]::NewGuid().ToString("N"))

            New-Item `
                -ItemType Directory `
                -Force `
                -Path $Restore |
                Out-Null

            Expand-Archive `
                -Path $Backup `
                -DestinationPath $Restore `
                -Force

            Get-ChildItem `
                -LiteralPath $Restore `
                -Force |
            ForEach-Object {
                Copy-Item `
                    -LiteralPath $_.FullName `
                    -Destination $ExtensionPath `
                    -Recurse `
                    -Force
            }

            Remove-Item `
                $Restore `
                -Recurse `
                -Force

            throw
        }

        return $ActualHash
    }
    finally {
        if(Test-Path $Work) {
            Remove-Item `
                $Work `
                -Recurse `
                -Force `
                -ErrorAction SilentlyContinue
        }
    }
}

if(-not (Test-Path $ConfigPath)) {
    exit 2
}

$Config =
    Get-Content $ConfigPath -Raw |
    ConvertFrom-Json

$ExtensionPath =
    [string]$Config.extension_path

$ServerUrl =
    ([string]$Config.server_url).TrimEnd('/')

$ExpectedPrefix =
    [string]$Config.github_release_path_prefix

$PollSeconds =
    [Math]::Max(
        30,
        [int]$Config.poll_seconds
    )

if(-not (Test-Path $ExtensionPath)) {
    exit 3
}

$Mutex =
    New-Object System.Threading.Mutex(
        $false,
        "Local\GM_Derken_Updater_v1"
    )

$HasLock =
    $false

try {
    $HasLock =
        $Mutex.WaitOne(
            0,
            $false
        )
}
catch {
    $HasLock = $false
}

if(-not $HasLock) {
    exit 0
}

Write-Utf8 `
    $PidPath `
    ([string]$PID)

try {
    while($true) {
        $CurrentVersion = ""

        try {
            $CurrentVersion =
                Get-ManifestVersion `
                    -ExtensionPath $ExtensionPath

            $Encoded =
                [Uri]::EscapeDataString(
                    $CurrentVersion
                )

            $Release =
                Invoke-RestMethod `
                    -Uri (
                        $ServerUrl +
                        "/api/public/release?current=" +
                        $Encoded
                    ) `
                    -Method Get `
                    -TimeoutSec 20

            if($Release.available) {
                if(
                    -not $Release.download_url -or
                    -not $Release.sha256_url
                ) {
                    throw "A Release não contém ZIP e SHA256."
                }

                Write-RuntimeState `
                    -ExtensionPath $ExtensionPath `
                    -Status "downloading" `
                    -Message (
                        "Baixando " +
                        [string]$Release.latest_version +
                        " automaticamente..."
                    ) `
                    -CurrentVersion $CurrentVersion `
                    -InstalledVersion $CurrentVersion

                $Hash =
                    Apply-Update `
                        -ExtensionPath $ExtensionPath `
                        -LatestVersion ([string]$Release.latest_version) `
                        -DownloadUrl ([string]$Release.download_url) `
                        -ShaUrl ([string]$Release.sha256_url) `
                        -ExpectedPrefix $ExpectedPrefix

                Write-RuntimeState `
                    -ExtensionPath $ExtensionPath `
                    -Status "updated" `
                    -Message (
                        "Versão " +
                        [string]$Release.latest_version +
                        " instalada e validada. A extensão será recarregada."
                    ) `
                    -CurrentVersion $CurrentVersion `
                    -InstalledVersion ([string]$Release.latest_version)
            }
            else {
                Write-RuntimeState `
                    -ExtensionPath $ExtensionPath `
                    -Status "active" `
                    -Message "Atualizador automático ativo." `
                    -CurrentVersion $CurrentVersion `
                    -InstalledVersion $CurrentVersion
            }
        }
        catch {
            if(-not $CurrentVersion) {
                try {
                    $CurrentVersion =
                        Get-ManifestVersion `
                            -ExtensionPath $ExtensionPath
                }
                catch {
                    $CurrentVersion = ""
                }
            }

            Write-RuntimeState `
                -ExtensionPath $ExtensionPath `
                -Status "error" `
                -Message (
                    "Falha no atualizador: " +
                    [string]$_.Exception.Message
                ) `
                -CurrentVersion $CurrentVersion `
                -InstalledVersion $CurrentVersion
        }

        Start-Sleep `
            -Seconds $PollSeconds
    }
}
finally {
    if($HasLock) {
        try {
            $Mutex.ReleaseMutex()
        }
        catch {}
    }

    $Mutex.Dispose()

    Remove-Item `
        $PidPath `
        -Force `
        -ErrorAction SilentlyContinue
}
