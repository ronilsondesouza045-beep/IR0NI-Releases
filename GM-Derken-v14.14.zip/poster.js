async function prepareDraft(text, publish, imagePayload = null) {
  if (!/^\/groups\/[^/]+/.test(location.pathname)) {
    return 'Abra primeiro a página do grupo.';
  }
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const normalize = value => (value || '').replace(/\s+/g, ' ').trim();
  const compact = value => (value || '').replace(/[\s\u200b-\u200d\ufeff\ufe0e\ufe0f]/g, '');
  const findEditor = () => document.querySelector('[role="dialog"] [role="textbox"][contenteditable="true"]');
  let editor = findEditor();
  if (!editor) {
    const start = [...document.querySelectorAll('[role="button"], button')].find(el =>
      /escreva algo|no que você está pensando|write something|create a public post|criar publicação/i
        .test((el.innerText || el.getAttribute('aria-label') || '').slice(0, 120)));
    if (start) start.click();
  }
  for (let attempt = 0; attempt < 25 && !editor; attempt++) {
    await sleep(300);
    editor = findEditor();
  }
  if (!editor) return 'Não encontrei o editor do grupo. Abra o campo de publicação manualmente e tente de novo.';
  const editorTexts = () => {
    const current = findEditor() || editor;
    return [current.innerText || '', current.textContent || ''];
  };
  const matchesRequested = () => editorTexts().some(value => {
    const actual = compact(value);
    const expected = compact(text);
    if (actual === expected) return true;
    // O editor pode anexar "Ver mais" ou "Ver menos" fora do texto digitado.
    return actual.startsWith(expected) && /^(Vermais|Vermenos|Seemore|Seeless)$/i.test(actual.slice(expected.length));
  });
  const requested = normalize(text);
  const existing = normalize(editorTexts()[0] || editorTexts()[1]);
  const dialog = (findEditor() || editor).closest('[role="dialog"]');
  if (!dialog) return 'Não consegui identificar a janela de publicação. Nenhum envio foi acionado.';
  if (existing && !matchesRequested()) {
    return 'O editor já contém outro texto. Revise-o antes de publicar.';
  }
  if (!existing && requested) {
    editor.focus();
    document.execCommand('insertText', false, text);
  }
  let verified = false;
  for (let attempt = 0; attempt < 20; attempt++) {
    if (matchesRequested()) {
      verified = true;
      break;
    }
    await sleep(150);
  }
  if (!verified) {
    const observed = compact(editorTexts()[1]).length;
    return `Não consegui confirmar o texto no editor (${observed} caracteres observados). Confira o editor; nenhum envio foi acionado.`;
  }
  if (imagePayload) {
    try {
      if (!['image/jpeg', 'image/png'].includes(imagePayload.mime) ||
          !imagePayload.base64 || imagePayload.base64.length > 4.3 * 1024 * 1024) {
        return 'Foto inválida ou maior que 3 MB. Nenhum envio foi acionado.';
      }
      const imagesBefore = new Set([...dialog.querySelectorAll('img')].map(img => img.currentSrc || img.src));
      let fileInput = dialog.querySelector('input[type="file"][accept*="image"]');
      if (!fileInput) {
        const photoButton = [...dialog.querySelectorAll('button, [role="button"]')].find(button =>
          /foto\/vídeo|foto\/video|photo\/video|adicionar foto|add photo/i.test(
            `${button.getAttribute('aria-label') || ''} ${button.innerText || ''}`.slice(0, 120)));
        if (photoButton) photoButton.click();
        for (let attempt = 0; attempt < 20 && !fileInput; attempt++) {
          await sleep(250);
          fileInput = dialog.querySelector('input[type="file"][accept*="image"]');
        }
      }
      if (!fileInput) return 'Não encontrei o controle de fotos no editor. Nenhum envio foi acionado.';
      const binary = atob(imagePayload.base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const file = new File([bytes], imagePayload.name, {type: imagePayload.mime});
      const transfer = new DataTransfer();
      transfer.items.add(file);
      fileInput.files = transfer.files;
      fileInput.dispatchEvent(new Event('input', {bubbles: true}));
      fileInput.dispatchEvent(new Event('change', {bubbles: true}));
      let previewConfirmed = false;
      for (let attempt = 0; attempt < 40; attempt++) {
        await sleep(250);
        if ([...dialog.querySelectorAll('img')].some(img =>
          img.complete && img.naturalWidth > 0 && !imagesBefore.has(img.currentSrc || img.src))) {
          previewConfirmed = true;
          break;
        }
      }
      if (!previewConfirmed) return 'Não consegui confirmar a prévia da foto. Confira o editor; nenhum envio foi acionado.';
    } catch (error) {
      return `Não consegui preparar a foto (${error.message || error}). Nenhum envio foi acionado.`;
    }
  }
  if (!publish) return imagePayload ? 'Foto e legenda preparadas no grupo.' : 'Texto preparado no grupo.';

  const buttons = [...(dialog || document).querySelectorAll('button, [role="button"]')];
  const postButton = buttons.find(button =>
    /^(postar|publicar|post|publish)$/i.test(
      normalize(button.innerText || button.getAttribute('aria-label'))
    ) && !button.disabled && button.getAttribute('aria-disabled') !== 'true');
  if (!postButton) return 'Texto pronto, mas não encontrei o botão Postar. Nenhum envio foi acionado.';
  const noticeSelector = '[role="alert"], [role="status"], [data-pagelet*="Toast"], [role="dialog"]';
  const notices = () => [...document.querySelectorAll(noticeSelector)]
    .filter(element => element !== dialog && !dialog.contains(element))
    .map(element => normalize(element.innerText || element.textContent).slice(0, 500));
  const noticesBefore = new Set(notices());
  const observedState = () => {
    const fresh = notices().filter(value => value && !noticesBefore.has(value));
    if (fresh.some(value => /temporariamente impedid[oa]|limite de publicaç|você não pode publicar|your account is restricted|you can't post|posting too fast/i.test(value))) {
      return {status: 'blocked', message: 'O Facebook mostrou uma restrição de publicação. Fila interrompida.'};
    }
    if (fresh.some(value => /aguardando aprovação|pendente de aprovação|enviad[oa].{0,45}aprovação|pending approval|waiting for approval|submitted for approval/i.test(value))) {
      return {status: 'pending', message: 'O Facebook indicou que este post aguarda aprovação do grupo.'};
    }
    if (fresh.some(value => /post(?:agem|e)?.{0,25}publicad[oa]|publicaç[ãa]o.{0,25}publicada|post.{0,25}published/i.test(value))) {
      return {status: 'published', message: 'O Facebook mostrou confirmação de publicação. Confira no grupo.'};
    }
    return null;
  };
  postButton.click();
  for (let attempt = 0; attempt < 40; attempt++) {
    await sleep(250);
    const observed = observedState();
    if (observed) return observed;
    if (!dialog?.isConnected || dialog.getAttribute('aria-hidden') === 'true') {
      for (let extra = 0; extra < 8; extra++) {
        await sleep(250);
        const delayed = observedState();
        if (delayed) return delayed;
      }
      return {status: 'submitted', message: 'Postar foi acionado e o editor fechou. Aprovação ainda não confirmada.'};
    }
  }
  return {status: 'uncertain', message: 'Postar foi acionado, mas o editor permaneceu aberto. Confira a página antes de repetir.'};
}
