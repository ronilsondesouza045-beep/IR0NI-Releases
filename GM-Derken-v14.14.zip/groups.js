const foundArea = document.getElementById('found-groups');
const loadStatus = document.getElementById('load-status');
const filterField = document.getElementById('filter-groups');
const loadButton = document.getElementById('load-groups');
const groupQueueField = document.getElementById('groups');
const queuePlanStatus = document.getElementById('queue-plan-status');

let loadedGroups = [];
let selectedIds = new Set();
let allowedIds = new Set();

const GROUPS_URL =
  'https://www.facebook.com/groups/joins/';

function filteredGroups() {
  const filter =
    (filterField?.value || '')
      .toLocaleLowerCase('pt-BR')
      .trim();

  return loadedGroups.filter(
    group =>
      !filter ||
      `${group.name} ${group.id}`
        .toLocaleLowerCase('pt-BR')
        .includes(filter)
  );
}

async function currentQueueLimit() {
  try {
    if (
      globalThis.IR0NILicense &&
      typeof globalThis.IR0NILicense.getState ===
        'function'
    ) {
      const state =
        await globalThis.IR0NILicense.getState();

      return state?.valid
        ? 250
        : 10;
    }
  }
  catch {}

  return 10;
}

function renderQueuePlanStatus(queued, limit) {
  if (!queuePlanStatus) return;

  const isPro = limit === 250;
  queuePlanStatus.classList.toggle('pro', isPro);
  queuePlanStatus.textContent =
    `Plano ${isPro ? 'PRO' : 'FREE'} · ` +
    `Encontrados ${loadedGroups.length} · ` +
    `Selecionados ${selectedIds.size} · ` +
    `Permitidos ${allowedIds.size} · ` +
    `Na fila ${queued}/${limit}`;
}

async function fillQueue() {
  const limit =
    await currentQueueLimit();

  if (!groupQueueField) {
    return {
      queued: 0,
      limit
    };
  }

  const chosen =
    loadedGroups
      .filter(
        group =>
          selectedIds.has(group.id) &&
          allowedIds.has(group.id)
      )
      .slice(0, limit);

  groupQueueField.value =
    chosen
      .map(
        group =>
          'https://www.facebook.com/groups/' +
          encodeURIComponent(group.id) +
          '/'
      )
      .join('\n');

  groupQueueField.dispatchEvent(
    new Event(
      'input',
      {
        bubbles: true
      }
    )
  );

  renderQueuePlanStatus(chosen.length, limit);

  return {
    queued: chosen.length,
    limit
  };
}

function renderLoadedGroups() {
  if (!foundArea || !loadStatus) {
    return;
  }

  foundArea.replaceChildren();

  const visible =
    filteredGroups();

  for (const group of visible) {
    const row =
      document.createElement('div');

    row.className =
      'group-entry';

    const label =
      document.createElement('label');

    label.className =
      'group-choice';

    const checkbox =
      document.createElement('input');

    checkbox.type =
      'checkbox';

    checkbox.checked =
      selectedIds.has(group.id);

    checkbox.disabled =
      !allowedIds.has(group.id);

    checkbox.addEventListener(
      'change',
      async () => {
        if (checkbox.checked) {
          selectedIds.add(group.id);
        }
        else {
          selectedIds.delete(group.id);
        }

        await chrome.storage.local.set({
          selectedGroupIds:
            [...selectedIds]
        });

        await fillQueue();
        renderLoadedGroups();
      }
    );

    if (
      group.photo &&
      /^https:\/\//.test(group.photo)
    ) {
      const picture =
        document.createElement('img');

      picture.className =
        'group-photo';

      picture.src =
        group.photo;

      picture.alt =
        '';

      picture.loading =
        'lazy';

      picture.onerror =
        () => picture.remove();

      label.append(
        checkbox,
        picture
      );
    }
    else {
      label.append(
        checkbox
      );
    }

    const text =
      document.createElement('span');

    text.append(
      document.createTextNode(
        group.name ||
        group.id
      )
    );

    const id =
      document.createElement('small');

    id.textContent =
      group.id;

    text.append(id);
    label.append(text);

    const permission =
      document.createElement('label');

    permission.className =
      'permit-label';

    const permissionBox =
      document.createElement('input');

    permissionBox.type =
      'checkbox';

    permissionBox.checked =
      allowedIds.has(group.id);

    permissionBox.addEventListener(
      'change',
      async () => {
        if (permissionBox.checked) {
          allowedIds.add(group.id);
          selectedIds.add(group.id);
        }
        else {
          allowedIds.delete(group.id);
          selectedIds.delete(group.id);
        }

        await chrome.storage.local.set({
          allowedGroupIds:
            [...allowedIds],

          selectedGroupIds:
            [...selectedIds]
        });

        await fillQueue();
        renderLoadedGroups();
      }
    );

    permission.append(
      permissionBox,
      document.createTextNode(
        'Divulgação permitida'
      )
    );

    row.append(
      label,
      permission
    );

    foundArea.appendChild(
      row
    );
  }

  loadStatus.textContent =
    loadedGroups.length
      ? (
          loadedGroups.length +
          ' grupo(s) salvos. A lista completa fica guardada; o limite FREE/PRO é aplicado somente à fila de cada execução.'
        )
      : 'Nenhum grupo sincronizado ainda.';
}

async function collectJoinedGroups() {
  /*
    IMPORTANTE:
    Tudo desta função é independente,
    pois ela será executada dentro da
    página do Facebook.
  */

  const pause =
    ms =>
      new Promise(
        resolve =>
          setTimeout(resolve, ms)
      );

  const excluded =
    new Set([
      'joins',
      'feed',
      'discover',
      'create',
      'search',
      'manage',
      'pending',
      'suggested',
      'notifications',
      'yourgroups',
      'your_groups',
      'admin',
      'posts',
      'reels',
      'events',
      'settings'
    ]);

  const genericName =
    value =>
      /^(ver grupo|view group|grupo|group)$/i
        .test(
          (value || '').trim()
        );

  if (
    !location.pathname
      .startsWith('/groups/joins')
  ) {
    return {
      error:
        'O Facebook abriu a lista de grupos em outro endereço.'
    };
  }

  if (
    (
      document.querySelector(
        'input[name="email"]'
      ) &&
      document.querySelector(
        'input[name="pass"]'
      )
    ) ||
    /^\/(login|checkpoint)(\/|$)/i
      .test(location.pathname)
  ) {
    return {
      error:
        'O Facebook pediu login ou verificação nesta sessão.'
    };
  }

  const found =
    new Map();

  const collect =
    () => {
      const anchors =
        document.querySelectorAll(
          'a[href*="/groups/"]'
        );

      for (const anchor of anchors) {
        let url;

        try {
          url =
            new URL(
              anchor.href ||
              anchor.getAttribute('href') ||
              '',
              location.origin
            );
        }
        catch {
          continue;
        }

        if (
          ![
            'facebook.com',
            'www.facebook.com',
            'm.facebook.com'
          ].includes(url.hostname)
        ) {
          continue;
        }

        const path =
          url.pathname
            .split('/')
            .filter(Boolean);

        const id =
          path[1];

        if (
          path[0] !== 'groups' ||
          !id ||
          excluded.has(
            id.toLowerCase()
          ) ||
          !/^[A-Za-z0-9_.-]+$/
            .test(id)
        ) {
          continue;
        }

        let name =
          (
            anchor.innerText ||
            anchor.getAttribute(
              'aria-label'
            ) ||
            ''
          )
            .trim()
            .split('\n')[0]
            .slice(0,140);

        if (
          genericName(name)
        ) {
          let card =
            anchor.parentElement;

          for (
            let depth = 0;
            depth < 5 && card;
            depth += 1,
            card = card.parentElement
          ) {
            const heading =
              card.querySelector(
                '[role="heading"],h2,h3'
              );

            const candidate =
              (
                heading?.innerText ||
                heading?.textContent ||
                ''
              )
                .trim()
                .split('\n')[0]
                .slice(0,140);

            if (
              candidate &&
              !genericName(candidate)
            ) {
              name =
                candidate;

              break;
            }
          }
        }

        if (
          !name &&
          !/^\d+$/.test(id)
        ) {
          continue;
        }

        const image =
          anchor.querySelector('img') ||
          anchor.parentElement
            ?.querySelector('img');

        const photo =
          image?.currentSrc ||
          image?.src ||
          '';

        const previous =
          found.get(id);

        found.set(
          id,
          {
            id,

            name:
              name &&
              !genericName(name)
                ? name
                : (
                    previous?.name &&
                    !genericName(
                      previous.name
                    )
                      ? previous.name
                      : (
                          name ||
                          id
                        )
                  ),

            photo:
              /^https:\/\//.test(photo)
                ? photo
                : (
                    previous?.photo ||
                    ''
                  )
          }
        );
      }
    };

  window.scrollTo(
    0,
    0
  );

  for (
    const element of
    document.querySelectorAll('*')
  ) {
    if (
      element.clientHeight > 150 &&
      element.scrollHeight >
        element.clientHeight + 100 &&
      [
        'auto',
        'scroll'
      ].includes(
        getComputedStyle(
          element
        ).overflowY
      )
    ) {
      element.scrollTop =
        0;
    }
  }

  await pause(600);

  let stableRounds =
    0;

  let previousCount =
    -1;

  for (
    let round = 0;
    round < 120 &&
    stableRounds < 10;
    round += 1
  ) {
    collect();

    if (
      found.size ===
      previousCount
    ) {
      stableRounds +=
        1;
    }
    else {
      previousCount =
        found.size;

      stableRounds =
        0;
    }

    window.scrollTo(
      0,
      document.body.scrollHeight
    );

    for (
      const element of
      document.querySelectorAll('*')
    ) {
      if (
        element.clientHeight > 180 &&
        element.scrollHeight >
          element.clientHeight + 150 &&
        [
          'auto',
          'scroll'
        ].includes(
          getComputedStyle(
            element
          ).overflowY
        )
      ) {
        element.scrollTop =
          element.scrollHeight;
      }
    }

    await pause(550);
  }

  collect();

  return {
    groups:
      [...found.values()]
  };
}

async function waitForTabComplete(
  tabId,
  timeoutMs = 45000
) {
  const started =
    Date.now();

  while (
    Date.now() -
    started <
    timeoutMs
  ) {
    const tab =
      await chrome.tabs.get(
        tabId
      );

    if (
      tab.status ===
      'complete'
    ) {
      return tab;
    }

    await new Promise(
      resolve =>
        setTimeout(
          resolve,
          350
        )
    );
  }

  throw new Error(
    'A lista de grupos demorou para carregar.'
  );
}

async function syncGroupsInBackground() {
  if (
    !loadButton ||
    !loadStatus
  ) {
    return;
  }

  const previousText =
    loadButton.textContent;

  loadButton.disabled =
    true;

  loadButton.textContent =
    'Sincronizando...';

  loadStatus.textContent =
    'Abrindo sua lista de grupos em segundo plano...';

  let tabId =
    null;

  let createdByExtension =
    false;

  try {
    const tabs =
      await chrome.tabs.query({});

    const existing =
      tabs.find(
        tab => {
          try {
            const url =
              new URL(
                tab.url ||
                ''
              );

            return (
              [
                'facebook.com',
                'www.facebook.com'
              ].includes(
                url.hostname
              ) &&
              url.pathname
                .startsWith(
                  '/groups/joins'
                )
            );
          }
          catch {
            return false;
          }
        }
      );

    if (
      existing?.id
    ) {
      tabId =
        existing.id;

      await chrome.tabs.reload(
        tabId
      );
    }
    else {
      const tab =
        await chrome.tabs.create({
          url:
            GROUPS_URL,

          active:
            false
        });

      tabId =
        tab.id;

      createdByExtension =
        true;
    }

    await waitForTabComplete(
      tabId
    );

    await new Promise(
      resolve =>
        setTimeout(
          resolve,
          1200
        )
    );

    loadStatus.textContent =
      'Lendo todos os grupos sem trocar sua aba atual...';

    const result =
      await chrome.scripting
        .executeScript({
          target: {
            tabId
          },

          func:
            collectJoinedGroups
        });

    const data =
      result?.[0]?.result;

    if (
      data?.error
    ) {
      throw new Error(
        data.error
      );
    }

    if (
      !Array.isArray(
        data?.groups
      ) ||
      !data.groups.length
    ) {
      throw new Error(
        'Nenhum grupo foi encontrado na lista do Facebook.'
      );
    }

    const previous =
      await chrome.storage.local.get(
        'knownGroups'
      );

    const previousGroups =
      Array.isArray(
        previous.knownGroups
      )
        ? previous.knownGroups
        : [];

    const merged =
      new Map(
        previousGroups.map(
          group => [
            group.id,
            group
          ]
        )
      );

    for (
      const group of
      data.groups
    ) {
      const old =
        merged.get(
          group.id
        );

      merged.set(
        group.id,
        {
          ...old,
          ...group,

          photo:
            group.photo ||
            old?.photo ||
            ''
        }
      );
    }

    loadedGroups =
      [...merged.values()];

    /*
      Configuração solicitada:
      todos os grupos encontrados
      ficam permitidos e selecionados
      LOCALMENTE.
    */

    allowedIds =
      new Set(
        loadedGroups.map(
          group =>
            group.id
        )
      );

    selectedIds =
      new Set(
        loadedGroups.map(
          group =>
            group.id
        )
      );

    await chrome.storage.local.set({
      knownGroups:
        loadedGroups,

      allowedGroupIds:
        [...allowedIds],

      selectedGroupIds:
        [...selectedIds],

      lastGroupSyncAt:
        Date.now(),

      lastGroupSyncCount:
        data.groups.length
    });

    const queue =
      await fillQueue();

    renderLoadedGroups();

    loadStatus.textContent =
      data.groups.length +
      ' grupo(s) encontrado(s) · ' +
      queue.queued +
      ' colocado(s) automaticamente na fila ' +
      (
        queue.limit === 250
          ? 'PRO'
          : 'FREE'
      ) +
      ' · todos marcados e selecionados.';

  }
  catch(error) {
    loadStatus.textContent =
      'Falha ao sincronizar: ' +
      (
        error?.message ||
        error
      );
  }
  finally {
    /*
      Só fecha a aba quando ela
      foi criada pela extensão.
      Aba que já era do usuário
      não é fechada.
    */

    if (
      createdByExtension &&
      tabId
    ) {
      try {
        await chrome.tabs.remove(
          tabId
        );
      }
      catch {}
    }

    loadButton.disabled =
      false;

    loadButton.textContent =
      previousText;
  }
}

async function restoreGroups() {
  const saved =
    await chrome.storage.local.get([
      'knownGroups',
      'selectedGroupIds',
      'allowedGroupIds',
      'lastGroupSyncAt',
      'lastGroupSyncCount'
    ]);

  loadedGroups =
    Array.isArray(
      saved.knownGroups
    )
      ? saved.knownGroups
      : [];

  selectedIds =
    new Set(
      Array.isArray(
        saved.selectedGroupIds
      )
        ? saved.selectedGroupIds
        : []
    );

  allowedIds =
    new Set(
      Array.isArray(
        saved.allowedGroupIds
      )
        ? saved.allowedGroupIds
        : []
    );

  renderLoadedGroups();

  const queue =
    await fillQueue();

  if (
    Number(
      saved.lastGroupSyncAt
    ) > 0 &&
    loadStatus
  ) {
    loadStatus.textContent =
      loadedGroups.length +
      ' grupo(s) salvos · ' +
      queue.queued +
      ' na fila ' +
      (
        queue.limit === 250
          ? 'PRO'
          : 'FREE'
      ) +
      ' · última sincronização ' +
      new Date(
        saved.lastGroupSyncAt
      ).toLocaleString(
        'pt-BR'
      ) +
      '.';
  }
}

function simplifyInterface() {
  if (
    loadButton
  ) {
    loadButton.textContent =
      'Sincronizar meus grupos';
  }

  /*
    Botões que ficaram redundantes.
  */

  for (
    const id of [
      'open-joined',
      'select-all',
      'allow-all-and-use',
      'use-groups'
    ]
  ) {
    const element =
      document.getElementById(
        id
      );

    if (
      element
    ) {
      element.hidden =
        true;
    }
  }

  const note =
    document.querySelector(
      '.groups-panel .note'
    );

  if (
    note
  ) {
    note.textContent =
      'FREE: até 10 grupos por execução · PRO: até 250. ' +
      'Sincronizar abre a lista do Facebook em segundo plano, ' +
      'encontra os grupos, marca todos e preenche a fila automaticamente. ' +
      'A marcação de permitido é local e não verifica as regras reais de cada grupo.';
  }
}

if (
  loadButton
) {
  loadButton.addEventListener(
    'click',
    syncGroupsInBackground
  );
}

filterField?.addEventListener(
  'input',
  renderLoadedGroups
);

document
  .getElementById(
    'deselect-all'
  )
  ?.addEventListener(
    'click',
    async () => {
      selectedIds.clear();

      await chrome.storage.local.set({
        selectedGroupIds: []
      });

      await fillQueue();
      renderLoadedGroups();
    }
  );

document
  .getElementById(
    'export-groups'
  )
  ?.addEventListener(
    'click',
    () => {
      if (
        !loadedGroups.length
      ) {
        loadStatus.textContent =
          'Nenhuma lista salva para exportar.';

        return;
      }

      const rows =
        loadedGroups.map(
          group =>
            group.id +
            '\t' +
            String(
              group.name ||
              group.id
            ).replace(
              /[\r\n\t]/g,
              ' '
            )
        );

      const url =
        URL.createObjectURL(
          new Blob(
            [
              rows.join('\n') +
              '\n'
            ],
            {
              type:
                'text/plain;charset=utf-8'
            }
          )
        );

      const link =
        document.createElement(
          'a'
        );

      link.href =
        url;

      link.download =
        'grupos-gm-derken.txt';

      link.click();

      setTimeout(
        () =>
          URL.revokeObjectURL(
            url
          ),
        60000
      );
    }
  );

document
  .getElementById(
    'clear-groups'
  )
  ?.addEventListener(
    'click',
    async () => {
      if (
        !confirm(
          'Apagar a lista de grupos salva nesta extensão?'
        )
      ) {
        return;
      }

      loadedGroups =
        [];

      selectedIds.clear();
      allowedIds.clear();

      await chrome.storage.local.remove([
        'knownGroups',
        'selectedGroupIds',
        'allowedGroupIds',
        'lastGroupSyncAt',
        'lastGroupSyncCount'
      ]);

      if (
        groupQueueField
      ) {
        groupQueueField.value =
          '';
      }

      renderLoadedGroups();
    }
  );

simplifyInterface();

restoreGroups()
  .catch(
    error => {
      if (
        loadStatus
      ) {
        loadStatus.textContent =
          'Falha ao restaurar grupos: ' +
          (
            error?.message ||
            error
          );
      }
    }
  );