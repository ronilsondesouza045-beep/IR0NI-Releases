(() => {
  'use strict';

  const SERVER =
    'https://ir0ni-api-production.up.railway.app';

  const byId =
    id =>
      document.getElementById(id);

  function cleanNotes(value) {
    return String(value || '')
      .split(/\r?\n/)
      .map(
        line =>
          line
            .replace(/^#{1,6}\s*/, '')
            .replace(/^[-*•✓]\s*/, '')
            .trim()
      )
      .filter(Boolean)
      .filter(
        line =>
          !/^https?:\/\//i.test(line)
      )
      .slice(0, 7);
  }

  function formatTime(value) {
    const parsed =
      Date.parse(
        value || ''
      );

    if (
      !Number.isFinite(
        parsed
      )
    ) {
      return '';
    }

    return new Date(
      parsed
    ).toLocaleTimeString(
      'pt-BR',
      {
        hour:
          '2-digit',

        minute:
          '2-digit'
      }
    );
  }

  async function heartbeat() {
    try {
      await chrome.runtime.sendMessage({
        type:
          'ironi:heartbeat',

        force:
          true
      });
    }
    catch {}
  }

  async function loadNews() {
    const current =
      chrome.runtime
        .getManifest()
        .version;

    const response =
      await fetch(
        SERVER +
        '/api/public/release?current=' +
        encodeURIComponent(
          current
        ),
        {
          cache:
            'no-store'
        }
      );

    if (!response.ok) {
      throw new Error(
        'HTTP ' +
        response.status
      );
    }

    return response.json();
  }

  async function loadAutoState() {
    let helper = null;
    let automatic = null;

    try {
      helper = await chrome.runtime.sendMessage({
        type: 'gmderken:updater-state'
      });
    }
    catch {}

    try {
      automatic = await chrome.runtime.sendMessage({
        type: 'gmderken:auto-update-check'
      });
    }
    catch {}

    const saved = await chrome.storage.local.get([
      'gmDerkenUpdaterState',
      'gmDerkenAutoUpdateState'
    ]);

    helper = helper || saved.gmDerkenUpdaterState || {};
    automatic = automatic || saved.gmDerkenAutoUpdateState || {};

    return {
      ...automatic,
      helperInstalled: Boolean(helper.helperInstalled),
      helperVersion: String(helper.helperVersion || ''),
      helperStatus: String(helper.status || ''),
      helperMessage: String(helper.message || ''),
      currentVersion: String(
        automatic.currentVersion ||
        helper.currentVersion ||
        chrome.runtime.getManifest().version
      ),
      lastCheck: String(automatic.lastCheck || helper.lastCheck || '')
    };
  }

  function renderNews(data) {
    const version =
      byId(
        'ironi-news-version'
      );

    const status =
      byId(
        'ironi-news-status'
      );

    const list =
      byId(
        'ironi-news-list'
      );

    if (
      !version ||
      !status ||
      !list
    ) {
      return;
    }

    const latest =
      data.latest_version ||
      data.release_name ||
      chrome.runtime
        .getManifest()
        .version;

    version.textContent =
      latest;

    if (
      data.available
    ) {
      status.textContent =
        'Nova versão detectada. A instalação será feita automaticamente.';

      status.classList.remove(
        'ok'
      );
    }
    else {
      status.textContent =
        'Você está usando a versão atual.';

      status.classList.add(
        'ok'
      );
    }

    list.replaceChildren();

    const notes =
      cleanNotes(
        data.notes
      );

    if (
      !notes.length
    ) {
      const li =
        document.createElement(
          'li'
        );

      li.textContent =
        'Sistema conectado e atualizado.';

      list.appendChild(
        li
      );

      return;
    }

    for (
      const note of
      notes
    ) {
      const li =
        document.createElement(
          'li'
        );

      li.textContent =
        note;

      list.appendChild(
        li
      );
    }
  }

  function renderUpdater(state) {
    const dot = byId('gm-updater-dot');
    const label = byId('gm-updater-state');
    const message = byId('gm-updater-message');

    if (!dot || !label || !message) return;

    dot.className = 'gm-updater-dot';

    const status = String(state?.status || state?.helperStatus || 'active');
    const helperVersion = String(state?.helperVersion || '');

    if (status === 'error') {
      dot.classList.add('error');
      label.textContent = 'atenção';
      message.textContent =
        state?.message || state?.helperMessage ||
        'O atualizador encontrou um problema.';
      return;
    }

    if (status === 'reloading') {
      dot.classList.add('working');
      label.textContent = 'recarregando';
      message.textContent =
        state?.message || 'Carregando automaticamente a nova versão...';
      return;
    }

    if (status === 'waiting_update' || status === 'downloading' || status === 'updated') {
      dot.classList.add('working');
      label.textContent = status === 'downloading' ? 'baixando' : 'atualizando';
      message.textContent =
        state?.message || state?.helperMessage ||
        'Atualização automática em andamento.';
      return;
    }

    dot.classList.add('active');
    label.textContent = 'ativo';

    const checked = formatTime(state?.lastCheck);
    message.textContent =
      'Atualização automática ativa' +
      (helperVersion ? ` · Helper ${helperVersion}` : '') +
      (checked ? ` · verificado ${checked}` : '') +
      '. Nenhuma atualização pendente.';
  }

  async function updateView() {
    const results =
      await Promise.all([
        loadNews()
          .catch(
            () => null
          ),

        loadAutoState()
          .catch(
            () => null
          )
      ]);

    const news =
      results[0];

    const auto =
      results[1];

    if (
      news
    ) {
      renderNews(
        news
      );
    }
    else {
      const status =
        byId(
          'ironi-news-status'
        );

      if (
        status
      ) {
        status.textContent =
          'Novidades temporariamente indisponíveis.';
      }
    }

    renderUpdater(
      auto
    );
  }

  heartbeat()
    .catch(() => {});

  updateView()
    .catch(() => {});

  setInterval(
    () => {
      updateView()
        .catch(() => {});
    },
    20000
  );
})();