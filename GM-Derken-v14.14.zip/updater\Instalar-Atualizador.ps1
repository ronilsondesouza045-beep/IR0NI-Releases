﻿$ErrorActionPreference = "Stop"

$ServerUrl =
    "https://ir0ni-api-production.up.railway.app"

$ReleasePrefix =
    "/ronilsondesouza045-beep/IR0NI-Releases/releases/download/"

$ExtensionPath =
    (Resolve-Path (
        Join-Path $PSScriptRoot ".."
    )).Path

$InstallDir =
    Join-Path `
        $env:LOCALAPPDATA `
        "GM-Derken-Updater"

$HelperSource =
    Join-Path `
        $PSScriptRoot `
        "GM-Derken-Updater.ps1"

$HelperDest =
    Join-Path `
        $InstallDir `
        "GM-Derken-Updater.ps1"

$ConfigDest =
    Join-Path `
        $InstallDir `
        "config.json"

function Write-Utf8 {
    param(
        [string]$Path,
        [string]$Text
    )

    $Encoding =
        New-Object System.Text.UTF8Encoding($false)

    [System.IO.File]::WriteAllText(
        $Path,
        $Text,
        $Encoding
    )
}

Write-Host ""
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host " GM DERKEN - INSTALADOR DO ATUALIZADOR" -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host ""

if(-not (Test-Path (
    Join-Path $ExtensionPath "manifest.json"
))) {
    throw "Execute este instalador dentro da pasta updater da extensão."
}

New-Item `
    -ItemType Directory `
    -Force `
    -Path $InstallDir |
    Out-Null

Get-CimInstance Win32_Process |
Where-Object {
    $_.CommandLine -and
    $_.CommandLine -like "*GM-Derken-Updater.ps1*" -and
    $_.ProcessId -ne $PID
} |
ForEach-Object {
    Stop-Process `
        -Id $_.ProcessId `
        -Force `
        -ErrorAction SilentlyContinue
}

Copy-Item `
    -LiteralPath $HelperSource `
    -Destination $HelperDest `
    -Force

$Config = [ordered]@{
    extension_path = $ExtensionPath
    server_url = $ServerUrl
    github_release_path_prefix = $ReleasePrefix
    poll_seconds = 60
}

Write-Utf8 `
    $ConfigDest `
    ($Config | ConvertTo-Json -Depth 10)

$RunCommand =
    'powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' +
    $HelperDest +
    '"'

$RunKey =
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"

New-Item `
    -Path $RunKey `
    -Force |
    Out-Null

New-ItemProperty `
    -Path $RunKey `
    -Name "GM Derken Updater" `
    -Value $RunCommand `
    -PropertyType String `
    -Force |
    Out-Null

Start-Process `
    -FilePath "powershell.exe" `
    -ArgumentList @(
        "-NoProfile",
        "-WindowStyle",
        "Hidden",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        "`"$HelperDest`""
    ) `
    -WindowStyle Hidden

Start-Sleep -Seconds 3

$RuntimeState =
    Join-Path `
        $ExtensionPath `
        "updater-runtime.json"

if(-not (Test-Path $RuntimeState)) {
    $Initial = [ordered]@{
        helper_version = "1.0.0"
        status = "active"
        last_check = (Get-Date).ToUniversalTime().ToString("o")
        current_version = ""
        installed_version = ""
        message = "Atualizador automático instalado. A primeira verificação ocorrerá em instantes."
    }

    Write-Utf8 `
        $RuntimeState `
        ($Initial | ConvertTo-Json -Depth 10)
}

Write-Host ""
Write-Host "ATUALIZADOR INSTALADO COM SUCESSO" -ForegroundColor Green
Write-Host ""
Write-Host "Pasta monitorada:" -ForegroundColor Yellow
Write-Host $ExtensionPath
Write-Host ""
Write-Host "A partir da v14.8, as próximas Releases serão:" -ForegroundColor Cyan
Write-Host "1. detectadas automaticamente"
Write-Host "2. baixadas automaticamente"
Write-Host "3. verificadas por SHA256"
Write-Host "4. copiadas para esta pasta"
Write-Host "5. recarregadas pela extensão"
Write-Host ""
Write-Host "Não apague a pasta:" -ForegroundColor Yellow
Write-Host $InstallDir
Write-Host ""
