(() => {
  'use strict';

  const SERVER =
    'https://ir0ni-api-production.up.railway.app';

  const ALARM =
    'gm-derken-auto-reload-v2';

  const STATE_KEY =
    'gmDerkenAutoUpdateState';

  const WATCH_KEY =
    'gmDerkenAutoUpdateWatch';

  const FALLBACK_DELAY =
    90000;

  const RELOAD_GAP =
    60000;

  const MAX_FALLBACK_ATTEMPTS =
    3;

  function normalizeVersion(value) {
    let parts =
      String(value || '')
        .replace(/^v/i, '')
        .split('.')
        .map(
          part =>
            Number.parseInt(
              part,
              10
            ) || 0
        );

    if (
      parts.length > 2 &&
      parts[0] === 0
    ) {
      parts =
        parts.slice(1);
    }

    return parts;
  }

  function newer(aValue, bValue) {
    const a =
      normalizeVersion(aValue);

    const b =
      normalizeVersion(bValue);

    const size =
      Math.max(
        a.length,
        b.length
      );

    for (
      let i = 0;
      i < size;
      i += 1
    ) {
      const x =
        a[i] || 0;

      const y =
        b[i] || 0;

      if (x > y) {
        return true;
      }

      if (x < y) {
        return false;
      }
    }

    return false;
  }

  async function saveState(values) {
    const saved =
      await chrome.storage.local.get(
        STATE_KEY
      );

    const previous =
      saved[STATE_KEY] || {};

    const next = {
      ...previous,
      ...values,
      lastCheck:
        new Date().toISOString()
    };

    await chrome.storage.local.set({
      [STATE_KEY]:
        next
    });

    return next;
  }

  async function readDiskVersion() {
    /*
      manifest.json já existe na extensão
      quando ela é carregada.

      O helper substitui esse mesmo arquivo
      quando instala a próxima Release.

      Tentamos ler os bytes atuais no disco.
    */

    const url =
      chrome.runtime.getURL(
        'manifest.json'
      ) +
      '?gm=' +
      Date.now();

    const response =
      await fetch(
        url,
        {
          cache: 'no-store'
        }
      );

    if (!response.ok) {
      throw new Error(
        'manifest HTTP ' +
        response.status
      );
    }

    const manifest =
      await response.json();

    return String(
      manifest.version ||
      ''
    );
  }

  async function loadRelease(current) {
    const response =
      await fetch(
        SERVER +
        '/api/public/release?current=' +
        encodeURIComponent(
          current
        ),
        {
          cache: 'no-store'
        }
      );

    if (!response.ok) {
      throw new Error(
        'Servidor HTTP ' +
        response.status
      );
    }

    return response.json();
  }

  function reloadSoon() {
    setTimeout(
      () => {
        chrome.runtime.reload();
      },
      1200
    );
  }

  async function check() {
    const current =
      chrome.runtime
        .getManifest()
        .version;

    let diskVersion =
      current;

    try {
      diskVersion =
        await readDiskVersion();
    }
    catch {
      /*
        Se a leitura direta falhar,
        ainda existe o fallback pelo servidor.
      */
    }

    /*
      Melhor caso:
      helper já trocou manifest.json no disco.
    */

    if (
      diskVersion &&
      newer(
        diskVersion,
        current
      )
    ) {
      await saveState({
        status:
          'reloading',

        currentVersion:
          current,

        diskVersion,

        latestVersion:
          diskVersion,

        message:
          'Nova versão instalada no disco. Recarregando automaticamente...'
      });

      reloadSoon();
      return;
    }

    const release =
      await loadRelease(
        current
      );

    const latest =
      String(
        release.latest_version ||
        ''
      );

    /*
      Nada novo.
    */

    if (
      !release.available ||
      !newer(
        latest,
        current
      )
    ) {
      await chrome.storage.local.remove(
        WATCH_KEY
      );

      await saveState({
        status:
          'active',

        currentVersion:
          current,

        diskVersion,

        latestVersion:
          latest || current,

        message:
          'Canal automático ativo. Nenhuma atualização pendente.'
      });

      return;
    }

    /*
      Existe uma Release mais nova.
      O helper deve baixá-la e copiá-la.
    */

    const now =
      Date.now();

    const saved =
      await chrome.storage.local.get(
        WATCH_KEY
      );

    let watch =
      saved[WATCH_KEY] || {};

    if (
      watch.latestVersion !==
      latest
    ) {
      watch = {
        latestVersion:
          latest,

        detectedAt:
          now,

        lastReloadAt:
          0,

        attempts:
          0
      };

      await chrome.storage.local.set({
        [WATCH_KEY]:
          watch
      });

      await saveState({
        status:
          'waiting_update',

        currentVersion:
          current,

        diskVersion,

        latestVersion:
          latest,

        message:
          'Nova versão detectada. Aguardando o helper instalar os arquivos.'
      });

      return;
    }

    const detectedAt =
      Number(
        watch.detectedAt ||
        now
      );

    const lastReloadAt =
      Number(
        watch.lastReloadAt ||
        0
      );

    const attempts =
      Number(
        watch.attempts ||
        0
      );

    /*
      Enquanto ainda estamos dentro
      da janela normal do helper,
      apenas esperamos.
    */

    if (
      now - detectedAt <
      FALLBACK_DELAY
    ) {
      await saveState({
        status:
          'waiting_update',

        currentVersion:
          current,

        diskVersion,

        latestVersion:
          latest,

        message:
          'Atualização encontrada. Aguardando instalação automática.'
      });

      return;
    }

    /*
      Segurança:
      não recarrega indefinidamente
      se o helper estiver quebrado.
    */

    if (
      attempts >=
      MAX_FALLBACK_ATTEMPTS
    ) {
      await saveState({
        status:
          'error',

        currentVersion:
          current,

        diskVersion,

        latestVersion:
          latest,

        message:
          'A versão nova foi detectada, mas o helper ainda não aplicou os arquivos.'
      });

      return;
    }

    if (
      lastReloadAt &&
      now - lastReloadAt <
      RELOAD_GAP
    ) {
      return;
    }

    /*
      Fallback:
      após dar tempo suficiente ao helper,
      fazemos uma tentativa controlada
      de recarregar a extensão.

      Se os arquivos já estiverem no disco,
      o Chrome sobe a versão nova.

      Se ainda não estiverem,
      a extensão antiga volta e tentará
      novamente depois.
    */

    watch.lastReloadAt =
      now;

    watch.attempts =
      attempts + 1;

    await chrome.storage.local.set({
      [WATCH_KEY]:
        watch
    });

    await saveState({
      status:
        'reloading',

      currentVersion:
        current,

      diskVersion,

      latestVersion:
        latest,

      message:
        'Tentativa automática de carregar a versão nova.'
    });

    reloadSoon();
  }

  async function ensureAlarm() {
    try {
      await chrome.alarms.clear(
        ALARM
      );
    }
    catch {}

    chrome.alarms.create(
      ALARM,
      {
        periodInMinutes:
          1
      }
    );
  }

  chrome.alarms.onAlarm.addListener(
    alarm => {
      if (
        alarm.name ===
        ALARM
      ) {
        check()
          .catch(
            async error => {
              await saveState({
                status:
                  'error',

                message:
                  'Falha ao verificar atualização: ' +
                  String(
                    error?.message ||
                    error
                  )
              });
            }
          );
      }
    }
  );

  chrome.runtime.onMessage.addListener(
    (
      message,
      _sender,
      sendResponse
    ) => {
      if (
        message?.type ===
        'gmderken:auto-update-check'
      ) {
        check()
          .then(
            async () => {
              const saved =
                await chrome.storage.local.get(
                  STATE_KEY
                );

              sendResponse(
                saved[STATE_KEY] ||
                {}
              );
            }
          )
          .catch(
            error => {
              sendResponse({
                status:
                  'error',

                message:
                  String(
                    error?.message ||
                    error
                  )
              });
            }
          );

        return true;
      }
    }
  );

  ensureAlarm()
    .then(
      () => check()
    )
    .catch(() => {});
})();