// Executada na aba da publicação original; não usa APIs privadas do Facebook.
async function shareOriginalToGroup(groupName, progressToken = '', progressGroupId = '') {
  const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
  const progress = phase => {
    if (progressToken && progressGroupId) {
      chrome.runtime.sendMessage({type: 'ironi-native-progress', token: progressToken,
        id: progressGroupId, phase}).catch(() => {});
    }
  };
  const clean = text => (text || '').replace(/\s+/g, ' ').trim();
  const normalized = text => clean(text).toLocaleLowerCase('pt-BR');
  const visible = node => {
    const box = node.getBoundingClientRect();
    return box.width > 0 && box.height > 0 && getComputedStyle(node).visibility !== 'hidden';
  };
  const fail = message => ({status: 'failed', message: `${message} Nenhum compartilhamento foi acionado.`});
  const buttons = root => [...root.querySelectorAll('button, [role="button"]')].filter(visible);
  const findDialog = pattern => [...document.querySelectorAll('[role="dialog"]')]
    .filter(visible).find(dialog => pattern.test(clean(dialog.innerText).slice(0, 150)));
  async function waitFor(getter, attempts = 40) {
    for (let i = 0; i < attempts; i++) {
      const value = getter();
      if (value) return value;
      await pause(300);
    }
    return null;
  }

  if (!['facebook.com', 'www.facebook.com', 'm.facebook.com'].includes(location.hostname) ||
      /^\/(login|checkpoint)(\/|$)/.test(location.pathname)) {
    return fail('A publicação original não abriu neste Facebook conectado.');
  }
  if (!groupName || /^(ver grupo|view group|grupo)$/i.test(clean(groupName))) {
    return fail('Falta o nome real do grupo. Atualize a lista de grupos na extensão.');
  }
  const shareButton = await waitFor(() => buttons(document).find(node =>
    /^(compartilhar|share)$/i.test(clean(node.innerText || node.getAttribute('aria-label'))) &&
    !node.closest('[role="dialog"]')));
  if (!shareButton) return fail('Não encontrei o botão Compartilhar na live original.');
  shareButton.click();

  const menu = await waitFor(() => findDialog(/^Compartilhar(?:\s|$)|^Share(?:\s|$)/i));
  if (!menu) return fail('O menu Compartilhar não apareceu.');
  // "Compartilhar agora" manda para o Feed. Usamos somente a opção Grupo.
  function findGroupLabels(root) {
    const labels = [];
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const textNode = walker.currentNode;
      if (!/^(grupo|group)$/i.test(clean(textNode.nodeValue))) continue;
      const element = textNode.parentElement;
      if (element && visible(element)) labels.push(element);
    }
    const named = [...root.querySelectorAll('[aria-label], [title]')].filter(node => visible(node) &&
      /^(grupo|group)$/i.test(clean(node.getAttribute('aria-label') || node.getAttribute('title'))));
    const candidates = labels.length ? labels : named;
    return [...new Set(candidates)].filter(node =>
      !candidates.some(other => other !== node && node.contains(other)));
  }
  // O painel de ícones pode ser renderizado em outro portal, fora do nó [role=dialog].
  // Restringimos a procura à área visível do painel para não clicar em outro grupo na página.
  const menuBox = menu.getBoundingClientRect();
  const withinSharePanel = node => {
    const box = node.getBoundingClientRect();
    const x = box.left + box.width / 2;
    const y = box.top + box.height / 2;
    if (menuBox.width >= 350 && menuBox.height >= 250) {
      return x >= menuBox.left && x <= menuBox.right && y >= menuBox.top && y <= menuBox.bottom;
    }
    return x >= innerWidth * .25 && x <= innerWidth * .75 &&
      y >= innerHeight * .15 && y <= innerHeight * .9;
  };
  const groupLabels = await waitFor(() => {
    const found = findGroupLabels(document.body).filter(withinSharePanel);
    return found.length ? found : null;
  }, 12);
  if (!groupLabels || groupLabels.length !== 1) {
    const count = groupLabels?.length || 0;
    return fail(count ? `Encontrei ${count} opções Grupo na área do painel; parei para evitar um destino errado.` :
      `A opção Grupo não foi encontrada na área do painel (rótulos na página: ${findGroupLabels(document.body).length}).`);
  }
  groupLabels[0].click();

  // O seletor de grupos do Facebook pode ser um painel sem role="dialog".
  // Identificamos a tela pelo título e pelo campo de busca, juntos.
  const chooserState = await waitFor(() => {
    const searches = [...document.querySelectorAll('input')].filter(node => visible(node) &&
      /(?:procurar|buscar|pesquisar|search)\s+(?:por\s+)?(?:grupos|groups)/i.test(
        clean([node.placeholder, node.getAttribute('aria-label')].filter(Boolean).join(' '))));
    if (searches.length !== 1) return null;
    const search = searches[0];
    let root = search;
    while (root && root !== document.body) {
      const heading = [...root.querySelectorAll('h1, h2, h3, [role="heading"]')]
        .find(node => visible(node) && /^(compartilhar em um grupo|share to a group)$/i.test(clean(node.innerText)));
      const plainTitle = [...root.querySelectorAll('div, span')].some(node => visible(node) &&
        /^(compartilhar em um grupo|share to a group)$/i.test(clean(node.innerText)) &&
        ![...node.children].some(child =>
          /^(compartilhar em um grupo|share to a group)$/i.test(clean(child.innerText))));
      if (heading || plainTitle || (root.getAttribute('role') === 'dialog' &&
          /compartilhar em um grupo|share to a group/i.test(clean(root.innerText).slice(0, 200)))) {
        return {chooser: root, search};
      }
      root = root.parentElement;
    }
    return null;
  });
  if (!chooserState) {
    const headings = [...document.querySelectorAll('h1, h2, h3, [role="heading"]')]
      .filter(visible).map(node => clean(node.innerText)).filter(Boolean).slice(-4).join(' / ');
    return fail(`Não encontrei a lista de grupos após escolher Grupo (títulos visíveis: ${headings || 'nenhum'}).`);
  }
  let {chooser, search} = chooserState;
  search.focus();
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
  if (!setter) return fail('A pesquisa de grupos não está disponível.');
  setter.call(search, groupName);
  search.dispatchEvent(new Event('input', {bubbles: true}));
  await pause(700);

  const name = normalized(groupName);
  const matchesForName = () => {
    // A lista de resultados pode estar fora do cabeçalho que contém a busca.
    let scope = chooser;
    while (scope) {
      const candidates = buttons(scope).filter(node => {
        const firstLine = (node.innerText || '').trim().split('\n')[0];
        return normalized(firstLine) === name;
      });
      const leaves = candidates.filter(node => !candidates.some(other => other !== node && node.contains(other)));
      if (leaves.length) {
        chooser = scope;
        return leaves;
      }
      if (scope === document.body) break;
      scope = scope.parentElement;
    }
    return [];
  };
  let matches = [];
  for (let i = 0; i < 25; i++) {
    matches = matchesForName();
    if (matches.length) break;
    await pause(300);
  }
  if (matches.length !== 1) {
    if (matches.length > 1) return {status: 'ambiguous', message: `Há mais de um grupo chamado "${groupName}" no Facebook. Este grupo foi ignorado; nenhum compartilhamento foi acionado.`};
    return fail(`Não encontrei "${groupName}" na lista de compartilhamento.`);
  }
  matches[0].click();

  const composer = await waitFor(() => findDialog(/^(Criar post|Create post)/i));
  if (!composer) return fail('O editor de compartilhamento do grupo não apareceu.');
  progress('Editor do grupo aberto; esperando o vídeo');
  const inspectPreview = () => {
    // innerText e medidas de layout podem ficar incompletos quando a janela
    // do Chrome está minimizada. textContent preserva o cartão no DOM.
    const text = clean(composer.textContent);
    // O selo "Grupo público" pode estar fora de textContent. O destino já
    // foi escolhido por um único nome exato na lista Compartilhar em um grupo,
    // e este editor abriu somente depois desse clique.
    const groupBadge = /grupo\s+(?:público|publico|privado|public|private)/i.test(text.slice(0, 300));
    const originalLiveCard = /(?:está|estava) ao vivo(?: agora)?|fez uma transmissão ao vivo|(?:is|was) live(?: now)?/i.test(text);
    const media = [...composer.querySelectorAll('img, video, [style*="background-image"]')].some(element => {
      const box = element.getBoundingClientRect();
      return box.width >= 180 && box.height >= 90;
    });
    return {ready: originalLiveCard || media, groupBadge, originalLiveCard, media};
  };
  if (!await waitFor(() => inspectPreview().ready, 100)) {
    const state = inspectPreview();
    return {status: 'uncertain', message: `O editor do grupo "${groupName}" está aberto, mas não confirmei a prévia (selo do grupo: ${state.groupBadge ? 'sim' : 'não'}; cartão da live: ${state.originalLiveCard ? 'sim' : 'não'}; mídia visível: ${state.media ? 'sim' : 'não'}). Postar não foi acionado; confira esta aba antes de repetir.`};
  }
  progress('Vídeo confirmado no editor');
  // O botão pode existir no DOM enquanto o Chrome adia o desenho de uma aba
  // sem foco. Depois de confirmar o diálogo e o vídeo, não exigir medidas de
  // layout para reconhecer exclusivamente Postar dentro desse editor.
  const postButton = await waitFor(() => [...composer.querySelectorAll('button, [role="button"]')]
    .find(node => /^(postar|publish|post)$/i.test(
    clean(node.textContent || node.getAttribute('aria-label'))) && !node.disabled &&
    node.getAttribute('aria-disabled') !== 'true'), 100);
  if (!postButton) return fail('O vídeo está pronto, mas o botão Postar não está disponível.');
  progress('Botão Postar disponível');

  const noticeSelector = '[role="alert"], [role="status"], [data-pagelet*="Toast"]';
  const notices = () => [...document.querySelectorAll(noticeSelector)].filter(visible)
    .map(node => clean(node.innerText || node.textContent).slice(0, 400));
  const before = new Set(notices());
  postButton.click();
  progress('Clique em Postar acionado; aguardando resposta do Facebook');
  for (let i = 0; i < 48; i++) {
    await pause(250);
    const fresh = notices().filter(value => value && !before.has(value));
    if (fresh.some(value => /temporariamente impedid[oa]|limite de publicaç|you can't post|posting too fast/i.test(value))) {
      return {status: 'blocked', message: 'O Facebook mostrou uma restrição. Fila interrompida.'};
    }
    if (fresh.some(value => /aguardando aprovação|pendente de aprovação|enviad[oa].{0,45}aprovação|pending approval/i.test(value))) {
      return {status: 'pending', message: 'Vídeo compartilhado; o Facebook mostrou aprovação pendente.'};
    }
    if (fresh.some(value => /post.{0,25}publicad[oa]|publicaç[ãa]o.{0,25}publicada|post.{0,25}published/i.test(value))) {
      return {status: 'published', message: 'O Facebook confirmou a publicação do vídeo compartilhado.'};
    }
    if (!composer.isConnected || !visible(composer)) {
      return {status: 'submitted', message: 'Compartilhar foi acionado e o editor fechou. Confira o vídeo no grupo.'};
    }
  }
  return {status: 'uncertain', message: 'Postar foi acionado, mas o editor continua aberto. Confira antes de repetir.'};
}
