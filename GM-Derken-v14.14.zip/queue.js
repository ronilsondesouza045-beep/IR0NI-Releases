const groupsField = document.getElementById('groups');
const postField = document.getElementById('post');
const modeField = document.getElementById('mode');
const linkField = document.getElementById('share-url');
const photoField = document.getElementById('photo');
const linkPhotoField = document.getElementById('link-photo');
const delayField = document.getElementById('delay');
const compactWorkWindow = document.getElementById('compact-work-window');
const fastQuotaLine = document.getElementById('fast-quota');
const FAST_WINDOW_MS = 24 * 60 * 60 * 1000;
const FAST_LIMIT = 100;
const startButton = document.getElementById('start');
const stopButton = document.getElementById('stop');
const executionMode = document.getElementById('execution-mode');
const batchStatus = document.getElementById('batch-status');
const FAST_BATCH_SIZE = 10;
const statusLine = document.getElementById('status');
const logList = document.getElementById('log');
const historyList = document.getElementById('history');
const resultBody = document.getElementById('group-results');
const progressCount = document.getElementById('progress-count');
const panelArtInput = document.getElementById('panel-art');
const panelArtStatus = document.getElementById('panel-art-status');
const proLiveMonitor = document.getElementById('pro-live-monitor');
const proMonitorToggle = document.getElementById('pro-monitor-toggle');
const proMonitorGroup = document.getElementById('pro-monitor-group');
const proMonitorStage = document.getElementById('pro-monitor-stage');
const proMonitorPosition = document.getElementById('pro-monitor-position');
const proMonitorBatch = document.getElementById('pro-monitor-batch');
const proMonitorProgressBar = document.getElementById('pro-monitor-progress-bar');
const proMonitorSuccess = document.getElementById('pro-monitor-success');
const proMonitorFailures = document.getElementById('pro-monitor-failures');
const proMonitorRemaining = document.getElementById('pro-monitor-remaining');
const proMonitorEvents = document.getElementById('pro-monitor-events');
const proMonitorStop = document.getElementById('pro-monitor-stop');
const proMonitorFacebook = document.getElementById('pro-monitor-facebook');
let proMonitorTotal = 0;
let proMonitorIndex = 0;
let proMonitorCurrentGroupId = null;
let proMonitorResults = new Map();
let currentWorkWindowId = null;
let stopRequested = false;
let running = false;
let history = [];
let groupNames = new Map();
let resultRows = new Map();
let savedCampaigns = [];
let runHistory = [];
let lastRun = null;
let activeRun = null;

const campaignNameField = document.getElementById('campaign-name');
const campaignSelect = document.getElementById('campaign-select');
const campaignStatus = document.getElementById('campaign-status');
const deleteCampaignButton = document.getElementById('delete-campaign');
const lastRunSummary = document.getElementById('last-run-summary');
const runHistoryList = document.getElementById('run-history');
const resumeLastRunButton = document.getElementById('resume-last-run');
const retryFailedButton = document.getElementById('retry-failed');

let licenseState = {valid: false};
const backgroundMode = document.getElementById('background-mode');
const advancedGuard = document.getElementById('advanced-guard');
const installIdLine = document.getElementById('install-id');
const licensePlan = document.getElementById('license-plan');
const licenseExpiry = document.getElementById('license-expiry');
const licenseMessage = document.getElementById('license-message');
const headerPlan = document.getElementById('header-plan');
const nativeOption = modeField.querySelector('option[value="native"]');

function proFeature(feature) {
  return IR0NILicense.hasFeature(licenseState, feature);
}


function proMonitorAllowed() {
  return Boolean(licenseState.valid && proFeature('queue_250'));
}

function proMonitorSetVisualState(state = '') {
  if (!proLiveMonitor) return;
  proLiveMonitor.classList.remove('running', 'warning', 'failed');
  if (state) proLiveMonitor.classList.add(state);
}

function proMonitorReset(total = 0, fastPro = false) {
  if (!proLiveMonitor || !proMonitorAllowed()) return;
  proMonitorTotal = total;
  proMonitorIndex = 0;
  proMonitorCurrentGroupId = null;
  proMonitorResults = new Map();
  proLiveMonitor.hidden = false;
  proLiveMonitor.classList.remove('minimized');
  proMonitorSetVisualState('running');
  proMonitorGroup.textContent = 'Preparando execução...';
  proMonitorStage.textContent = 'Abrindo a janela de trabalho.';
  proMonitorPosition.textContent = `0/${total}`;
  proMonitorBatch.textContent = fastPro ? `⚡ Rápido PRO · lotes de ${FAST_BATCH_SIZE}` : 'Modo normal';
  proMonitorProgressBar.style.width = '0%';
  proMonitorSuccess.textContent = '0';
  proMonitorFailures.textContent = '0';
  proMonitorRemaining.textContent = String(total);
  proMonitorEvents.replaceChildren();
  proMonitorStop.disabled = false;
  proMonitorFacebook.disabled = true;
  proMonitorEvent('Monitor PRO iniciado.');
}

function proMonitorEvent(message, level = '') {
  if (!proLiveMonitor || proLiveMonitor.hidden || !proMonitorAllowed()) return;
  const line = document.createElement('li');
  if (level) line.className = level;
  const time = document.createElement('time');
  time.textContent = new Date().toLocaleTimeString('pt-BR');
  const text = document.createElement('span');
  text.textContent = String(message || '').slice(0, 180);
  line.append(time, text);
  proMonitorEvents.appendChild(line);
  while (proMonitorEvents.children.length > 24) proMonitorEvents.firstElementChild?.remove();
  proMonitorEvents.scrollTop = proMonitorEvents.scrollHeight;
}

function proMonitorSetStage(message, level = '') {
  if (!proLiveMonitor || proLiveMonitor.hidden || !proMonitorAllowed()) return;
  proMonitorStage.textContent = String(message || '').slice(0, 150);
  if (level === 'bad') proMonitorSetVisualState('failed');
  else if (level === 'warn') proMonitorSetVisualState('warning');
  else if (running) proMonitorSetVisualState('running');
}

function proMonitorSetCurrent(index, total, group, fastPro = false) {
  if (!proLiveMonitor || proLiveMonitor.hidden || !proMonitorAllowed()) return;
  proMonitorIndex = index + 1;
  proMonitorTotal = total;
  proMonitorCurrentGroupId = group?.id || null;
  proMonitorGroup.textContent = groupNames.get(group?.id) || group?.id || 'Grupo atual';
  proMonitorPosition.textContent = `${Math.min(proMonitorIndex, total)}/${total}`;
  const pct = total > 0 ? Math.max(0, Math.min(100, (index / total) * 100)) : 0;
  proMonitorProgressBar.style.width = `${pct}%`;
  if (fastPro) {
    const batch = Math.floor(index / FAST_BATCH_SIZE) + 1;
    const batches = Math.ceil(total / FAST_BATCH_SIZE);
    proMonitorBatch.textContent = `⚡ Lote ${batch}/${batches}`;
  } else {
    proMonitorBatch.textContent = 'Modo normal';
  }
}

function proMonitorRecordResult(id, status) {
  if (!proLiveMonitor || proLiveMonitor.hidden || !proMonitorAllowed()) return;
  const final = isRunSuccess(status) || isRunFailure(status);
  if (final) proMonitorResults.set(id, status);
  let success = 0;
  let failures = 0;
  for (const value of proMonitorResults.values()) {
    if (isRunSuccess(value)) success++;
    else if (isRunFailure(value)) failures++;
  }
  const done = success + failures;
  proMonitorSuccess.textContent = String(success);
  proMonitorFailures.textContent = String(failures);
  proMonitorRemaining.textContent = String(Math.max(0, proMonitorTotal - done));
  const pct = proMonitorTotal > 0 ? Math.max(0, Math.min(100, (done / proMonitorTotal) * 100)) : 0;
  proMonitorProgressBar.style.width = `${pct}%`;
  if (id === proMonitorCurrentGroupId) proMonitorSetStage(status, isRunFailure(status) ? 'bad' : (isRunSuccess(status) ? '' : ''));
}

function proMonitorFinish(label, state = '') {
  if (!proLiveMonitor || proLiveMonitor.hidden || !proMonitorAllowed()) return;
  proMonitorStage.textContent = label;
  proMonitorSetVisualState(state);
  proMonitorStop.disabled = true;
  const done = [...proMonitorResults.values()].filter(value => isRunSuccess(value) || isRunFailure(value)).length;
  const pct = proMonitorTotal > 0 ? Math.max(0, Math.min(100, (done / proMonitorTotal) * 100)) : 0;
  proMonitorProgressBar.style.width = `${pct}%`;
  proMonitorEvent(label, state === 'failed' ? 'bad' : state === 'warning' ? 'warn' : 'ok');
}

proMonitorToggle?.addEventListener('click', () => {
  if (!proLiveMonitor) return;
  const minimized = proLiveMonitor.classList.toggle('minimized');
  proMonitorToggle.textContent = minimized ? '□' : '—';
  proMonitorToggle.title = minimized ? 'Expandir monitor' : 'Recolher monitor';
  proMonitorToggle.setAttribute('aria-label', proMonitorToggle.title);
});

proMonitorStop?.addEventListener('click', () => {
  if (!running || stopRequested) return;
  stopRequested = true;
  proMonitorStop.disabled = true;
  report('Parada solicitada pelo Monitor PRO. Aguardando o grupo atual.');
});

proMonitorFacebook?.addEventListener('click', async () => {
  if (!currentWorkWindowId) {
    proMonitorEvent('A janela do Facebook ainda não está disponível.', 'warn');
    return;
  }
  try {
    await chrome.windows.update(currentWorkWindowId, {focused: true, state: 'normal'});
    proMonitorEvent('Janela do Facebook trazida para frente.');
  } catch {
    currentWorkWindowId = null;
    proMonitorFacebook.disabled = true;
    proMonitorEvent('A janela do Facebook foi fechada.', 'warn');
  }
});

function setProControlState(element, enabled) {
  const controls = element.matches('button,input,select,textarea') ? [element] : [...element.querySelectorAll('button,input,select,textarea')];
  for (const control of controls) control.disabled = !enabled;
  element.classList.toggle('pro-locked', !enabled);
  element.setAttribute('aria-disabled', String(!enabled));
}

function applyLicenseUI() {
  const isPro = Boolean(licenseState.valid);
  if (!isPro && proLiveMonitor) proLiveMonitor.hidden = true;
  licensePlan.textContent = isPro ? 'PRO ATIVO' : 'FREE';
  licensePlan.className = `plan-badge ${isPro ? 'pro' : 'free'}`;
  headerPlan.textContent = isPro ? 'PRO' : 'FREE';
  if (isPro) {
    const expiry = new Date(licenseState.expiresAt);
    licenseExpiry.textContent = `Válido até ${expiry.toLocaleDateString('pt-BR')}`;
  } else {
    licenseExpiry.textContent = licenseState.reason || 'Recursos básicos liberados';
  }
  for (const element of document.querySelectorAll('[data-pro-feature]')) {
    setProControlState(element, proFeature(element.dataset.proFeature));
  }
  if (nativeOption) nativeOption.disabled = !proFeature('native_share');
  if (!proFeature('native_share') && modeField.value === 'native') modeField.value = 'text';
  document.getElementById('pro-tools-note').textContent = isPro
    ? 'PRO ativo: até 250 grupos por execução + Monitor PRO ao vivo + múltiplas campanhas + retomar execução + repetir falhas + histórico completo + live original + Guardião avançado.'
    : 'FREE: você pode sincronizar e salvar toda a sua lista de grupos, mas cada execução usa no máximo 10. PRO libera até 250, campanhas, retomada e histórico avançado.';
  if (executionMode) {
    const fastAllowed = proFeature('queue_250');
    executionMode.disabled = !fastAllowed || running;
    if (!fastAllowed && executionMode.value === 'fast') executionMode.value = 'normal';
    updateExecutionModeUI();
  }
  updateMode();
  if (typeof renderCampaignManager === 'function') renderCampaignManager();
  if (typeof renderRunHistory === 'function') renderRunHistory();
}

async function refreshLicense() {
  licenseState = await IR0NILicense.getState();
  installIdLine.textContent = licenseState.installId;
  applyLicenseUI();
  return licenseState;
}


const serverDot = document.getElementById('server-dot');
const serverStateLine = document.getElementById('server-state');
const serverLastSeen = document.getElementById('server-last-seen');
const onlineMessage = document.getElementById('online-message');
const downloadUpdateButton = document.getElementById('download-update');
function formatSeen(value) { const t=Date.parse(value||''); return Number.isFinite(t)?new Date(t).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}):'—'; }
async function renderOnlineState(forceLicense=false) {
  const state=await IR0NIOnline.getState();
  const configured=Boolean(IR0NIOnline.serverUrl());
  serverDot.className='server-dot '+(state.connected?'online':'offline');
  serverStateLine.textContent=state.connected ? `Conectado · ${state.plan || 'FREE'}${state.license?.valid ? ' · licença validada' : ''}` : (configured ? 'Servidor indisponível' : 'Servidor ainda não configurado');
  serverLastSeen.textContent=state.checked_at ? `checado ${formatSeen(state.checked_at)}` : '—';
  onlineMessage.textContent=state.connected ? `Presença ativa. O painel administrativo consegue ver este ID, versão ${state.client_version || chrome.runtime.getManifest().version} e última conexão.` : (state.reason || 'Configure o endereço do servidor antes de distribuir a extensão.');
  if (downloadUpdateButton) {
    downloadUpdateButton.hidden = true;
  }

  if (state?.update?.available) {
    onlineMessage.textContent +=
      ' Nova versão detectada; o Atualizador GM Derken cuidará da instalação automaticamente.';
  }
  if(forceLicense) await refreshLicense();
}
document.getElementById('connect-server').addEventListener('click', async()=>{
  onlineMessage.textContent='Solicitando conexão com o servidor GM Derken...';
  const result=await IR0NIOnline.connect();
  onlineMessage.textContent=result?.ok ? 'Servidor conectado e presença registrada.' : (result?.reason || 'Falha na conexão.');
  await renderOnlineState(true);
});
document.getElementById('check-server').addEventListener('click', async()=>{
  onlineMessage.textContent='Verificando servidor, licença e atualização...';
  const result=await IR0NIOnline.heartbeat();
  onlineMessage.textContent=result?.ok ? 'Verificação concluída.' : (result?.reason || 'Servidor indisponível.');
  await renderOnlineState(true);
});
if (downloadUpdateButton) downloadUpdateButton.hidden = true;
chrome.storage.onChanged.addListener((changes,area)=>{ if(area==='local'&&changes.ironiOnlineState) renderOnlineState(true).catch(()=>{}); });
renderOnlineState(false).catch(()=>{});

async function inspectFacebookIdentity() {
  const loginForm = document.querySelector('input[name="email"]') && document.querySelector('input[name="pass"]');
  const needsLogin = Boolean(loginForm || /^\/(login|checkpoint)(\/|$)/i.test(location.pathname));
  const candidates = [...document.querySelectorAll('a[aria-label]')]
    .map(a => ({label: (a.getAttribute('aria-label') || '').trim(), href: a.href || ''}))
    .filter(x => x.label && x.label.length <= 80 && /facebook\.com\//i.test(x.href));
  const ignored = /^(Página inicial|Home|Menu|Messenger|Notificações|Notifications|Conta|Account|Seu perfil|Your profile)$/i;
  const profile = candidates.find(x => !ignored.test(x.label) && (/profile\.php|\/me(?:\/|$)/.test(x.href))) ||
    candidates.find(x => !ignored.test(x.label) && !/\/groups\//.test(x.href));
  return {needsLogin, name: profile?.label || '', title: document.title.slice(0, 100)};
}

async function detectAccount() {
  const nameLine = document.getElementById('account-name');
  const stateLine = document.getElementById('account-state');
  nameLine.textContent = 'Verificando sessão...';
  stateLine.textContent = 'Procurando uma aba do Facebook neste Chrome.';
  try {
    const tabs = await chrome.tabs.query({url: ['https://facebook.com/*', 'https://*.facebook.com/*']});
    const tab = tabs.find(t => t.active) || tabs[0];
    if (!tab?.id) {
      nameLine.textContent = 'Facebook não encontrado';
      stateLine.textContent = 'Abra facebook.com neste Chrome para detectar a sessão.';
      return;
    }
    const [result] = await chrome.scripting.executeScript({target: {tabId: tab.id}, func: inspectFacebookIdentity});
    if (result?.result?.needsLogin) {
      nameLine.textContent = 'Login necessário';
      stateLine.textContent = 'Entre no Facebook diretamente na aba; a extensão não recebe sua senha.';
      return;
    }
    nameLine.textContent = result?.result?.name || 'Facebook conectado';
    stateLine.textContent = 'Sessão detectada neste perfil do Chrome.';
  } catch (error) {
    nameLine.textContent = 'Não foi possível detectar';
    stateLine.textContent = String(error?.message || error);
  }
}

function inspectSafetyPage() {
  const path = location.pathname;
  if (/^\/(login|checkpoint)(\/|$)/i.test(path)) return {login: true, restriction: false, reason: 'Facebook pediu login/checkpoint.'};
  const text = (document.body?.innerText || '').slice(0, 180000);
  const restrictionPatterns = [
    /temporariamente bloquead[oa]/i,
    /you(?:'|’)re temporarily blocked/i,
    /não é possível usar (?:este|esse) recurso no momento/i,
    /you can(?:not|'t) use this feature right now/i,
    /sua conta foi (?:suspensa|bloqueada)/i,
    /your account (?:has been|was) suspended/i
  ];
  const matched = restrictionPatterns.find(re => re.test(text));
  return {login: false, restriction: Boolean(matched), reason: matched ? 'O Facebook exibiu um aviso de restrição.' : ''};
}

async function safetyCheck(tabId, advanced) {
  const [result] = await chrome.scripting.executeScript({target: {tabId}, func: inspectSafetyPage});
  const state = result?.result || {};
  if (state.login) throw new Error(`${state.reason} Fila parada para proteger a sessão.`);
  if (advanced && state.restriction) throw new Error(`${state.reason} Guardião PRO interrompeu a fila.`);
}

document.getElementById('detect-account').addEventListener('click', detectAccount);
document.getElementById('copy-install-id').addEventListener('click', async () => {
  await navigator.clipboard.writeText(installIdLine.textContent);
  licenseMessage.textContent = 'ID copiado. Envie este ID ao administrador para receber a licença.';
});
document.getElementById('activate-license').addEventListener('click', async () => {
  const token = document.getElementById('license-token').value.trim();
  licenseMessage.textContent = 'Validando licença...';
  const state = await IR0NILicense.activate(token);
  if (!state.valid) {
    licenseMessage.textContent = state.reason || 'Licença inválida.';
    return;
  }
  licenseState = state;
  document.getElementById('license-token').value = '';
  if (state.payload?.online_required) {
    licenseMessage.textContent = 'Chave assinada aceita. Validando no servidor GM Derken...';
    await IR0NIOnline.connect().catch(() => null);
    licenseState = await IR0NILicense.getState();
  }
  licenseMessage.textContent = licenseState.valid ? 'PRO ativado e validado neste Chrome.' : (licenseState.reason || 'A chave foi salva, mas precisa de validação online.');
  applyLicenseUI();
  await renderOnlineState(false);
});
document.getElementById('deactivate-license').addEventListener('click', async () => {
  licenseState = await IR0NILicense.deactivate();
  licenseMessage.textContent = 'Licença removida deste Chrome.';
  applyLicenseUI();
});

chrome.storage.local.get(['backgroundMode', 'advancedGuard']).then(saved => {
  if (typeof saved.backgroundMode === 'boolean') backgroundMode.checked = saved.backgroundMode;
  if (typeof saved.advancedGuard === 'boolean') advancedGuard.checked = saved.advancedGuard;
});
backgroundMode.addEventListener('change', () => chrome.storage.local.set({backgroundMode: backgroundMode.checked}));
advancedGuard.addEventListener('change', () => chrome.storage.local.set({advancedGuard: advancedGuard.checked}));

function campaignSnapshot() {
  return {mode: modeField.value, post: postField.value, link: linkField.value, delay: delayField.value,
    executionMode: executionMode?.value || 'normal', groups: groupsField.value, compact: compactWorkWindow.checked, background: backgroundMode.checked,
    guard: advancedGuard.checked, savedAt: Date.now()};
}

function cleanCampaignName(value) {
  return String(value || '').replace(/\s+/g, ' ').trim().slice(0, 60);
}

function applyCampaignSnapshot(c, campaignName = '') {
  if (!c || typeof c !== 'object') return false;
  modeField.value = ['text','link','photo','native'].includes(c.mode) ? c.mode : 'text';
  if (modeField.value === 'native' && !proFeature('native_share')) modeField.value = 'text';
  postField.value = c.post || '';
  linkField.value = c.link || '';
  delayField.value = c.delay || '30';
  if (executionMode) executionMode.value = c.executionMode === 'fast' && proFeature('queue_250') ? 'fast' : 'normal';
  updateExecutionModeUI();
  groupsField.value = c.groups || '';
  compactWorkWindow.checked = c.compact !== false;
  backgroundMode.checked = Boolean(c.background);
  advancedGuard.checked = c.guard !== false;
  if (campaignNameField && campaignName) campaignNameField.value = campaignName;
  updateMode();
  return true;
}

async function saveCampaignStore() {
  savedCampaigns = savedCampaigns.slice(-30);
  await chrome.storage.local.set({ironiCampaignPresetsV2: savedCampaigns});
}

function renderCampaignManager() {
  if (!campaignSelect) return;
  const previous = campaignSelect.value;
  campaignSelect.replaceChildren();
  const empty = document.createElement('option');
  empty.value = '';
  empty.textContent = savedCampaigns.length ? 'Selecione uma campanha' : 'Nenhuma campanha salva';
  campaignSelect.appendChild(empty);
  for (const item of [...savedCampaigns].sort((a,b) => (b.updatedAt || 0) - (a.updatedAt || 0))) {
    const option = document.createElement('option');
    option.value = item.id;
    option.textContent = `${item.name} · ${new Date(item.updatedAt || item.createdAt || Date.now()).toLocaleDateString('pt-BR')}`;
    campaignSelect.appendChild(option);
  }
  if ([...campaignSelect.options].some(option => option.value === previous)) campaignSelect.value = previous;
  if (deleteCampaignButton) deleteCampaignButton.disabled = !campaignSelect.value || !proFeature('campaign_presets');
}

async function loadCampaignStore() {
  const saved = await chrome.storage.local.get(['ironiCampaignPresetsV2', 'ironiCampaignPreset']);
  savedCampaigns = Array.isArray(saved.ironiCampaignPresetsV2) ? saved.ironiCampaignPresetsV2.filter(item => item && item.id && item.snapshot) : [];
  if (!savedCampaigns.length && saved.ironiCampaignPreset) {
    const now = Date.now();
    savedCampaigns = [{id: crypto.randomUUID(), name: 'Campanha antiga', snapshot: saved.ironiCampaignPreset, createdAt: now, updatedAt: now}];
    await saveCampaignStore();
    if (campaignStatus) campaignStatus.textContent = 'Sua campanha antiga foi migrada para o novo gerenciador PRO.';
  }
  renderCampaignManager();
}

document.getElementById('save-campaign').addEventListener('click', async () => {
  if (!proFeature('campaign_presets')) return;
  const name = cleanCampaignName(campaignNameField?.value);
  if (!name) { campaignStatus.textContent = 'Dê um nome para a campanha antes de salvar.'; campaignNameField?.focus(); return; }
  const selectedId = campaignSelect?.value || '';
  let item = savedCampaigns.find(entry => entry.id === selectedId);
  const now = Date.now();
  if (!item) {
    item = {id: crypto.randomUUID(), createdAt: now};
    savedCampaigns.push(item);
  }
  item.name = name;
  item.snapshot = campaignSnapshot();
  item.updatedAt = now;
  await saveCampaignStore();
  renderCampaignManager();
  campaignSelect.value = item.id;
  deleteCampaignButton.disabled = false;
  campaignStatus.textContent = `Campanha “${name}” salva. Fotos precisam ser escolhidas novamente ao carregar.`;
  report(`Campanha PRO “${name}” salva neste Chrome.`);
});

document.getElementById('load-campaign').addEventListener('click', () => {
  if (!proFeature('campaign_presets')) return;
  const item = savedCampaigns.find(entry => entry.id === campaignSelect?.value);
  if (!item) { campaignStatus.textContent = 'Selecione uma campanha salva.'; return; }
  applyCampaignSnapshot(item.snapshot, item.name);
  campaignStatus.textContent = `Campanha “${item.name}” carregada. Confira os grupos antes de iniciar.`;
  report(`Campanha PRO “${item.name}” carregada.`);
});

campaignSelect?.addEventListener('change', () => {
  const item = savedCampaigns.find(entry => entry.id === campaignSelect.value);
  if (item && campaignNameField) campaignNameField.value = item.name;
  if (deleteCampaignButton) deleteCampaignButton.disabled = !item || !proFeature('campaign_presets');
});

deleteCampaignButton?.addEventListener('click', async () => {
  if (!proFeature('campaign_presets')) return;
  const item = savedCampaigns.find(entry => entry.id === campaignSelect?.value);
  if (!item) return;
  if (!confirm(`Excluir a campanha “${item.name}”?`)) return;
  savedCampaigns = savedCampaigns.filter(entry => entry.id !== item.id);
  await saveCampaignStore();
  if (campaignNameField) campaignNameField.value = '';
  renderCampaignManager();
  campaignStatus.textContent = 'Campanha removida.';
});

loadCampaignStore().catch(() => {
  if (campaignStatus) campaignStatus.textContent = 'Não foi possível carregar as campanhas salvas.';
});

document.getElementById('export-history').addEventListener('click', () => {
  if (!proFeature('history_export')) return;
  const escape = v => `"${String(v ?? '').replaceAll('"','""')}"`;
  const rows = [['data','execucao','campanha','grupo','id','estado'], ...history.map(item => [
    new Date(item.time).toISOString(), item.runId || '', item.campaign || '', item.name || item.id, item.id, item.status
  ])];
  const csv = '\ufeff' + rows.map(row => row.map(escape).join(';')).join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], {type:'text/csv;charset=utf-8'}));
  const a = document.createElement('a'); a.href = url; a.download = `GM-Derken-historico-${new Date().toISOString().slice(0,10)}.csv`; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

refreshLicense().then(() => detectAccount()).catch(() => {});

function applyPanelArt(dataUrl) {
  const valid = typeof dataUrl === 'string' && /^data:image\/(?:jpeg|png|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(dataUrl);
  document.body.classList.toggle('has-panel-art', valid);
  if (valid) document.body.style.setProperty('--panel-art', `url("${dataUrl}")`);
  else document.body.style.removeProperty('--panel-art');
  panelArtStatus.textContent = valid ? 'Sua imagem está aplicada ao painel.' : 'Arte original da cidadela aplicada.';
}

chrome.storage.local.get('panelArtDataUrl').then(saved => applyPanelArt(saved.panelArtDataUrl))
  .catch(() => { panelArtStatus.textContent = 'Não foi possível recuperar a imagem salva.'; });
panelArtInput.addEventListener('change', async () => {
  const file = panelArtInput.files?.[0];
  if (!file) return;
  if (!['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(file.type) || file.size > 2 * 1024 * 1024 || !file.size) {
    panelArtStatus.textContent = 'Use JPG, PNG, WebP ou GIF de até 2 MB.';
    panelArtInput.value = '';
    return;
  }
  try {
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error('Não foi possível ler o arquivo.'));
      reader.readAsDataURL(file);
    });
    await chrome.storage.local.set({panelArtDataUrl: dataUrl});
    applyPanelArt(dataUrl);
  } catch {
    panelArtStatus.textContent = 'Não foi possível salvar a imagem. Tente uma foto menor.';
  }
  panelArtInput.value = '';
});
document.getElementById('clear-panel-art').addEventListener('click', async () => {
  try {
    await chrome.storage.local.remove('panelArtDataUrl');
    applyPanelArt(null);
  } catch { panelArtStatus.textContent = 'Não foi possível remover a imagem salva.'; }
});

chrome.storage.local.get('compactWorkWindow').then(saved => {
  if (typeof saved.compactWorkWindow === 'boolean' && !running) {
    compactWorkWindow.checked = saved.compactWorkWindow;
  }
});
compactWorkWindow.addEventListener('change', () => {
  chrome.storage.local.set({compactWorkWindow: compactWorkWindow.checked});
});

async function fastQuota() {
  const saved = await chrome.storage.local.get('fastGroupStarts');
  const now = Date.now();
  const recent = (Array.isArray(saved.fastGroupStarts) ? saved.fastGroupStarts : [])
    .filter(stamp => Number.isFinite(stamp) && stamp <= now && stamp > now - FAST_WINDOW_MS);
  if (recent.length !== (saved.fastGroupStarts || []).length) {
    await chrome.storage.local.set({fastGroupStarts: recent});
  }
  fastQuotaLine.textContent = `Modo rápido neste Chrome: ${recent.length}/${FAST_LIMIT} grupos iniciados nas últimas 24 horas.`;
  return recent;
}

async function reserveFastGroup() {
  const recent = await fastQuota();
  if (recent.length >= FAST_LIMIT) return false;
  recent.push(Date.now());
  await chrome.storage.local.set({fastGroupStarts: recent});
  fastQuotaLine.textContent = `Modo rápido neste Chrome: ${recent.length}/${FAST_LIMIT} grupos iniciados nas últimas 24 horas.`;
  return true;
}

fastQuota().catch(() => { fastQuotaLine.textContent = 'Não foi possível ler o uso do modo rápido.'; });

function updateExecutionModeUI() {
  if (!executionMode || !batchStatus) return;
  const isFast = executionMode.value === 'fast' && proFeature('queue_250');
  batchStatus.classList.toggle('fast', isFast);
  batchStatus.textContent = isFast
    ? `⚡ Rápido PRO · lotes de ${FAST_BATCH_SIZE} · respeita o intervalo`
    : 'Modo normal';
  if (isFast && advancedGuard) {
    advancedGuard.checked = true;
    chrome.storage.local.set({advancedGuard: true}).catch(() => {});
  }
}

executionMode?.addEventListener('change', async () => {
  if (executionMode.value === 'fast' && !proFeature('queue_250')) {
    executionMode.value = 'normal';
  }
  updateExecutionModeUI();
  await chrome.storage.local.set({executionMode: executionMode.value}).catch(() => {});
});

chrome.storage.local.get('executionMode').then(saved => {
  if (executionMode && !running) {
    executionMode.value = saved.executionMode === 'fast' && proFeature('queue_250') ? 'fast' : 'normal';
    updateExecutionModeUI();
  }
}).catch(() => updateExecutionModeUI());

async function nextGroupInterval(index, total, chosenDelay, fastPro) {
  const fastRequested = fastPro || chosenDelay < 30;
  if (fastRequested && (await fastQuota()).length >= FAST_LIMIT) return Math.max(30, chosenDelay);
  return chosenDelay;
}


function updateMode() {
  document.getElementById('link-options').hidden = !['link', 'native'].includes(modeField.value);
  document.getElementById('native-description').hidden = modeField.value !== 'native';
  document.getElementById('link-photo-wrap').hidden = modeField.value !== 'link';
  document.getElementById('post-options').hidden = modeField.value === 'native';
  document.getElementById('photo-options').hidden = modeField.value !== 'photo';
}
modeField.addEventListener('change', updateMode);
updateMode();

function readPhoto(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Não foi possível ler a foto.'));
    reader.onload = () => resolve({name: file.name, mime: file.type, base64: String(reader.result).split(',')[1]});
    reader.readAsDataURL(file);
  });
}

function validatedPostLink(value) {
  let url;
  try { url = new URL(value.trim()); } catch { throw new Error('Informe um link completo da publicação ou live.'); }
  if (url.protocol !== 'https:' ||
      !['facebook.com', 'www.facebook.com', 'm.facebook.com', 'fb.watch'].includes(url.hostname) ||
      !url.pathname.replace(/\//g, '')) {
    throw new Error('Informe um link HTTPS público do Facebook ou fb.watch.');
  }
  return url.href;
}

const SUCCESS_RUN_STATUSES = new Set([
  'envio acionado',
  'aguardando aprovação',
  'publicado (confirmação na tela)',
  'já enviado antes — ignorado'
]);

function normalizedRunStatus(value) {
  return String(value || '').trim().toLocaleLowerCase('pt-BR');
}

function isRunSuccess(status) {
  return SUCCESS_RUN_STATUSES.has(normalizedRunStatus(status));
}

function isRunFailure(status) {
  const value = normalizedRunStatus(status);
  return Boolean(value) && !isRunSuccess(value) && (
    value === 'falhou' || value === 'incerto' || value === 'restrição detectada' ||
    value === 'nome ambíguo — ignorado' || value.startsWith('falha ao abrir:')
  );
}

function runStats(run) {
  const groups = Array.isArray(run?.groups) ? run.groups : [];
  const results = run?.results && typeof run.results === 'object' ? run.results : {};
  let success = 0;
  let failures = 0;
  for (const group of groups) {
    const status = results[group.id]?.status || '';
    if (isRunSuccess(status)) success++;
    else if (isRunFailure(status)) failures++;
  }
  return {total: groups.length, success, failures, remaining: Math.max(0, groups.length - success)};
}

function renderRunHistory() {
  if (!lastRunSummary || !runHistoryList) return;
  if (!lastRun) {
    lastRunSummary.textContent = 'Nenhuma execução PRO registrada.';
    runHistoryList.replaceChildren();
    if (resumeLastRunButton) resumeLastRunButton.disabled = true;
    if (retryFailedButton) retryFailedButton.disabled = true;
    return;
  }
  const stats = runStats(lastRun);
  const name = lastRun.campaignName || 'Execução avulsa';
  lastRunSummary.textContent = `${name} · ${stats.success}/${stats.total} concluídos · ${stats.failures} falhas · ${stats.remaining} restantes · ${lastRun.status || 'em andamento'}`;
  if (resumeLastRunButton) resumeLastRunButton.disabled = !proFeature('campaign_presets') || stats.remaining < 1;
  if (retryFailedButton) retryFailedButton.disabled = !proFeature('campaign_presets') || stats.failures < 1;
  runHistoryList.replaceChildren();
  for (const run of [...runHistory].slice(-10).reverse()) {
    const li = document.createElement('li');
    const s = runStats(run);
    const when = new Date(run.finishedAt || run.startedAt || Date.now()).toLocaleString('pt-BR');
    const stateClass = run.status === 'completed' ? 'run-ok' : (run.status === 'failed' ? 'run-bad' : 'run-warn');
    li.className = stateClass;
    li.textContent = `${when} · ${run.campaignName || 'Execução avulsa'} · ${s.success}/${s.total} concluídos · ${s.failures} falhas · ${run.status || 'finalizada'}`;
    runHistoryList.appendChild(li);
  }
}

async function loadRunHistory() {
  const saved = await chrome.storage.local.get(['ironiLastRun', 'ironiRunHistory']);
  lastRun = saved.ironiLastRun && typeof saved.ironiLastRun === 'object' ? saved.ironiLastRun : null;
  runHistory = Array.isArray(saved.ironiRunHistory) ? saved.ironiRunHistory.filter(Boolean).slice(-25) : [];
  renderRunHistory();
}

async function persistActiveRun() {
  if (!activeRun) return;
  lastRun = activeRun;
  await chrome.storage.local.set({ironiLastRun: activeRun});
  renderRunHistory();
}

async function archiveActiveRun(status) {
  if (!activeRun) return;
  activeRun.status = status;
  activeRun.finishedAt = Date.now();
  activeRun.updatedAt = Date.now();
  lastRun = activeRun;
  runHistory = runHistory.filter(item => item?.id !== activeRun.id);
  runHistory.push(activeRun);
  runHistory = runHistory.slice(-25);
  await chrome.storage.local.set({ironiLastRun: activeRun, ironiRunHistory: runHistory});
  activeRun = null;
  renderRunHistory();
}

async function markActiveRunResult(id, status) {
  if (!activeRun || !id) return;
  if (!activeRun.results || typeof activeRun.results !== 'object') activeRun.results = {};
  activeRun.results[id] = {status, time: Date.now(), name: groupNames.get(id) || id};
  activeRun.updatedAt = Date.now();
  await persistActiveRun();
}

async function prepareLastRunSubset(kind) {
  if (!proFeature('campaign_presets')) return;
  if (!lastRun || !Array.isArray(lastRun.groups) || !lastRun.groups.length) {
    report('Nenhuma execução PRO disponível para retomar.');
    return;
  }
  const results = lastRun.results && typeof lastRun.results === 'object' ? lastRun.results : {};
  const targets = lastRun.groups.filter(group => {
    const status = results[group.id]?.status || '';
    return kind === 'failed' ? isRunFailure(status) : !isRunSuccess(status);
  });
  if (!targets.length) {
    report(kind === 'failed' ? 'A última execução não tem falhas registradas.' : 'A última execução não tem grupos restantes.');
    return;
  }
  applyCampaignSnapshot(lastRun.snapshot || {}, lastRun.campaignName || '');
  groupsField.value = targets.map(group => group.url || `https://www.facebook.com/groups/${encodeURIComponent(group.id)}/`).join('\n');
  groupsField.dispatchEvent(new Event('input', {bubbles: true}));
  report(kind === 'failed'
    ? `Preparadas ${targets.length} falhas da última execução. Confira a fila e clique em Iniciar publicações.`
    : `Retomada preparada com ${targets.length} grupos ainda não concluídos. Confira a fila e clique em Iniciar publicações.`);
}

resumeLastRunButton?.addEventListener('click', () => prepareLastRunSubset('resume'));
retryFailedButton?.addEventListener('click', () => prepareLastRunSubset('failed'));
loadRunHistory().catch(() => {});

function renderHistory() {
  historyList.replaceChildren();
  for (const item of history.slice(-500).reverse()) {
    const line = document.createElement('li');
    line.textContent = `${new Date(item.time).toLocaleString('pt-BR')} — ${item.name || item.id}: ${item.status}`;
    historyList.appendChild(line);
  }
}

async function recordResult(id, hash, status) {
  const entry = {id, name: groupNames.get(id) || id, hash, status, time: Date.now(),
    runId: activeRun?.id || '', campaign: activeRun?.campaignName || ''};
  history.push(entry);
  history = history.slice(-500);
  if (activeRun) {
    if (!activeRun.results || typeof activeRun.results !== 'object') activeRun.results = {};
    activeRun.results[id] = {status, time: entry.time, name: entry.name};
    activeRun.updatedAt = entry.time;
    lastRun = activeRun;
    await chrome.storage.local.set({postingHistory: history, ironiLastRun: activeRun});
    renderRunHistory();
  } else {
    await chrome.storage.local.set({postingHistory: history});
  }
  renderHistory();
}

chrome.storage.local.get(
  [
    'postingHistory',
    'knownGroups',
    'selectedGroupIds',
    'allowedGroupIds',
    'ironiLastRun',
    'ironiRunHistory'
  ]
).then(
  async saved => {
    history =
      Array.isArray(
        saved.postingHistory
      )
        ? saved.postingHistory
        : [];

    lastRun = saved.ironiLastRun && typeof saved.ironiLastRun === 'object' ? saved.ironiLastRun : lastRun;
    runHistory = Array.isArray(saved.ironiRunHistory) ? saved.ironiRunHistory.filter(Boolean).slice(-25) : runHistory;
    renderRunHistory();

    groupNames =
      new Map(
        (
          Array.isArray(
            saved.knownGroups
          )
            ? saved.knownGroups
            : []
        ).map(
          group => [
            group.id,
            group.name
          ]
        )
      );

    renderHistory();

    for (
      const item of
      history.slice(-250)
    ) {
      updateGroupResult(
        item.id,
        item.status
      );
    }

    if (
      history.length
    ) {
      progressCount.textContent =
        `${Math.min(history.length,250)} resultados recentes disponíveis.`;
    }

    if (
      !groupsField.value.trim()
    ) {
      const selected =
        new Set(
          Array.isArray(
            saved.selectedGroupIds
          )
            ? saved.selectedGroupIds
            : []
        );

      const allowed =
        new Set(
          Array.isArray(
            saved.allowedGroupIds
          )
            ? saved.allowedGroupIds
            : []
        );

      let maxInitial =
        10;

      try {
        const license =
          await IR0NILicense.getState();

        if (
          license?.valid
        ) {
          maxInitial =
            250;
        }
      }
      catch {}

      const chosen =
        [...groupNames.keys()]
          .filter(
            id =>
              selected.has(id) &&
              allowed.has(id)
          )
          .slice(
            0,
            maxInitial
          );

      groupsField.value =
        chosen
          .map(
            id =>
              `https://www.facebook.com/groups/${encodeURIComponent(id)}/`
          )
          .join('\n');
    }
  }
);
function updateGroupResult(id, status) {
  let cell = resultRows.get(id);
  if (!cell) {
    const row = document.createElement('tr');
    const nameCell = document.createElement('td');
    nameCell.textContent = groupNames.get(id) || id;
    cell = document.createElement('td');
    const timeCell = document.createElement('td');
    row.append(nameCell, cell, timeCell);
    resultBody.appendChild(row);
    resultRows.set(id, cell);
  }
  cell.previousElementSibling.textContent = groupNames.get(id) || id;
  cell.textContent = status;
  cell.nextElementSibling.textContent = new Date().toLocaleTimeString('pt-BR');
  proMonitorRecordResult(id, status);
}

function report(message) {
  statusLine.textContent = message;
  const line = document.createElement('li');
  line.textContent = `${new Date().toLocaleTimeString('pt-BR')} — ${message}`;
  logList.appendChild(line);
  line.scrollIntoView({block: 'nearest'});
  proMonitorSetStage(message);
  proMonitorEvent(message);
}

function parseGroup(line) {
  const value = line.trim();
  let id = value;
  if (value.includes('/')) {
    let url;
    try { url = new URL(value.startsWith('http') ? value : `https://${value}`); }
    catch { throw new Error(`Link inválido: ${value}`); }
    const segments = url.pathname.split('/').filter(Boolean);
    if (!['facebook.com', 'www.facebook.com'].includes(url.hostname) || segments[0] !== 'groups') {
      throw new Error(`Não é um link de grupo: ${value}`);
    }
    id = segments[1];
  }
  if (!id || !/^[A-Za-z0-9_.-]+$/.test(id) ||
      ['joins', 'feed', 'discover', 'create'].includes(id.toLowerCase())) {
    throw new Error(`ID de grupo inválido: ${value}`);
  }
  return {id, url: `https://www.facebook.com/groups/${encodeURIComponent(id)}/`};
}

function waitForNavigation(tabId, url) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => finish(new Error('A página do grupo demorou para carregar.')), 45000);
    function finish(error) {
      clearTimeout(timeout);
      chrome.tabs.onUpdated.removeListener(updated);
      error ? reject(error) : resolve();
    }
    function updated(changedTabId, change, tab) {
      if (changedTabId === tabId && change.status === 'complete') {
        if (tab.url === 'about:blank') return;
        try {
          const current = new URL(tab.url);
          const expected = new URL(url);
          if (['facebook.com', 'www.facebook.com'].includes(current.hostname) &&
              current.pathname.replace(/\/$/, '') === expected.pathname.replace(/\/$/, '')) {
            finish();
          } else {
            finish(new Error('O Facebook abriu outra página. Fila interrompida.'));
          }
        } catch {
          finish(new Error('A página do grupo não foi reconhecida.'));
        }
      }
    }
    chrome.tabs.onUpdated.addListener(updated);
    chrome.tabs.update(tabId, {url}).catch(finish);
  });
}

function waitForOriginal(tabId, url) {
  return new Promise((resolve, reject) => {
    let done = false;
    const timeout = setTimeout(() => finish(new Error('A live original demorou para abrir.')), 45000);
    function finish(error) {
      if (done) return;
      done = true;
      clearTimeout(timeout);
      chrome.tabs.onUpdated.removeListener(updated);
      error ? reject(error) : resolve();
    }
    function updated(changedId, change, tab) {
      if (changedId !== tabId || change.status !== 'complete' || tab.url === 'about:blank') return;
      try {
        const address = new URL(tab.url);
        if (address.protocol === 'https:' &&
            ['facebook.com', 'www.facebook.com', 'm.facebook.com'].includes(address.hostname) &&
            /^\/(watch\/|[^/]+\/videos\/|share\/v\/)/i.test(address.pathname)) finish();
        else finish(new Error('O link da live não abriu uma página de vídeo do Facebook. Fila interrompida.'));
      } catch { finish(new Error('Não reconheci o endereço da publicação original.')); }
    }
    chrome.tabs.onUpdated.addListener(updated);
    chrome.tabs.update(tabId, {url}).catch(finish);
  });
}

async function readGroupIdentity(expectedId) {
  const parts = location.pathname.split('/').filter(Boolean);
  if (parts[0] !== 'groups' || parts[1] !== expectedId) {
    return {error: 'O Facebook não abriu o grupo esperado.'};
  }
  const generic = value => /^(ver grupo|view group|grupo|group|facebook)$/i.test((value || '').trim());
  const title = [...document.querySelectorAll('h1, [role="heading"][aria-level="1"]')]
    .map(node => (node.innerText || node.textContent || '').trim().split('\n')[0])
    .find(value => value && !generic(value));
  const fallback = document.title.replace(/\s*[|–-]\s*Facebook\s*$/i, '').trim();
  const name = title || (!generic(fallback) ? fallback : '');
  return name ? {name: name.slice(0, 140)} : {error: 'Não consegui ler o nome desse grupo.'};
}

async function waitSeconds(seconds) {
  for (let elapsed = 0; elapsed < seconds && !stopRequested; elapsed++) {
    if (elapsed % 5 === 0 || elapsed === seconds - 1) {
      statusLine.textContent = `Próximo grupo em ${seconds - elapsed} segundos. Pode parar após o grupo atual.`;
    }
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
}

async function run() {
  if (running) return;
  let groups;
  let delay;
  let messageHash;
  let postText;
  let imagePayload = null;
  let sourceLink = '';
  let mode;
  let fastPro = false;
  try {
    groups = groupsField.value.split(/\r?\n/).filter(line => line.trim()).map(parseGroup);
    const unique = new Set(groups.map(item => item.id));
    const maxGroups = proFeature('queue_250') ? 250 : 10;
    if (groups.length < 1 || groups.length > maxGroups || unique.size !== groups.length) {
      throw new Error(`Plano ${licenseState.valid ? 'PRO' : 'FREE'}: informe de 1 a ${maxGroups} grupos diferentes.`);
    }
    const savedPermissions = await chrome.storage.local.get('allowedGroupIds');
    const allowed = new Set(Array.isArray(savedPermissions.allowedGroupIds) ? savedPermissions.allowedGroupIds : []);
    const unreviewed = groups.find(group => !allowed.has(group.id));
    if (unreviewed) throw new Error(`Revise as regras de ${unreviewed.id} e marque Divulgação permitida na lista de grupos.`);
    mode = modeField.value;
    if (!['text', 'link', 'photo', 'native'].includes(mode)) throw new Error('Tipo de publicação inválido.');
    if (mode === 'native' && !proFeature('native_share')) throw new Error('Compartilhar a live original é um recurso PRO.');
    const caption = postField.value.trim();
    if (mode === 'text' && !caption) throw new Error('Digite o texto da publicação.');
    const link = ['link', 'native'].includes(mode) ? validatedPostLink(linkField.value) : '';
    if (mode === 'native') {
      const address = new URL(link);
      if (!['facebook.com', 'www.facebook.com'].includes(address.hostname) ||
          !/^\/(share\/v\/|[^/]+\/videos\/|watch\/)/i.test(address.pathname)) {
        throw new Error('Para compartilhar o vídeo original, use o link da live no Facebook (ex.: facebook.com/share/v/...).');
      }
      sourceLink = link;
      const savedGroups = await chrome.storage.local.get('knownGroups');
      groupNames = new Map((Array.isArray(savedGroups.knownGroups) ? savedGroups.knownGroups : []).map(group => [group.id, group.name]));
    }
    postText = mode === 'link' ? [caption, caption.includes(link) ? '' : link].filter(Boolean).join('\n\n') : caption;
    if (mode === 'photo' || (mode === 'link' && linkPhotoField.files?.length)) {
      const file = mode === 'photo' ? photoField.files?.[0] : linkPhotoField.files?.[0];
      if (!file || !['image/jpeg', 'image/png'].includes(file.type) || file.size === 0 || file.size > 3 * 1024 * 1024) {
        throw new Error('Escolha uma foto JPG ou PNG de até 3 MB.');
      }
      imagePayload = await readPhoto(file);
    }
    delay = Number(delayField.value);
    if (!Number.isInteger(delay) || delay < 3 || delay > 600) {
      throw new Error('Escolha um intervalo entre 3 e 600 segundos.');
    }
    fastPro = executionMode?.value === 'fast' && proFeature('queue_250');
    if (executionMode?.value === 'fast' && !fastPro) {
      throw new Error('Modo Rápido é um recurso PRO.');
    }
    if (fastPro) {
      advancedGuard.checked = true;
      await chrome.storage.local.set({advancedGuard: true});
    }
    const hashBytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(
      JSON.stringify({mode, postText, sourceLink, photo: imagePayload?.base64 || ''})));
    messageHash = [...new Uint8Array(hashBytes)].map(byte => byte.toString(16).padStart(2, '0')).join('');
    const saved = await chrome.storage.local.get('postingHistory');
    history = Array.isArray(saved.postingHistory) ? saved.postingHistory : [];
    renderHistory();
    const campaignName = cleanCampaignName(campaignNameField?.value) || 'Execução avulsa';
    activeRun = {
      id: crypto.randomUUID(),
      campaignName,
      startedAt: Date.now(),
      updatedAt: Date.now(),
      status: 'running',
      hash: messageHash,
      mode,
      executionMode: fastPro ? 'fast' : 'normal',
      snapshot: campaignSnapshot(),
      groups: groups.map(group => ({id: group.id, url: group.url, name: groupNames.get(group.id) || group.id})),
      results: {}
    };
    await persistActiveRun();
    // Já enviados serão ignorados para permitir retomar a fila sem repetir publicações.
  } catch (error) {
    report(error.message);
    return;
  }

  running = true;
  stopRequested = false;
  startButton.disabled = true;
  stopButton.disabled = false;
  groupsField.disabled = true;
  postField.disabled = true;
  modeField.disabled = true;
  linkField.disabled = true;
  photoField.disabled = true;
  linkPhotoField.disabled = true;
  delayField.disabled = true;
  if (executionMode) executionMode.disabled = true;
  compactWorkWindow.disabled = true;
  backgroundMode.disabled = true;
  advancedGuard.disabled = true;
  resultBody.replaceChildren();
  resultRows = new Map();
  let finished = 0;
  let skipped = 0;
  progressCount.textContent = `0 de ${groups.length} verificados.`;
  if (proMonitorAllowed()) proMonitorReset(groups.length, fastPro);
  let tabId;
  let workWindowId;
  let compact = compactWorkWindow.checked;
  const progressToken = crypto.randomUUID();
  const progressListener = (message, sender) => {
    if (message?.type !== 'ironi-native-progress' || message.token !== progressToken ||
        sender.tab?.id !== tabId || !groups.some(group => group.id === message.id)) return;
    updateGroupResult(message.id, message.phase);
    if (message.phase.startsWith('Clique em Postar')) {
      report(`${message.id}: ${message.phase}.`);
    }
  };
  let interrupted = false;
  let failed = false;
  let currentGroup = null;
  if (fastPro) {
    const batches = Math.ceil(groups.length / FAST_BATCH_SIZE);
    batchStatus.textContent = `⚡ Lote 1/${batches} · 0/${groups.length}`;
    batchStatus.classList.add('fast');
    report(`⚡ Modo Rápido PRO: ${groups.length} grupos em ${batches} lote(s) de até ${FAST_BATCH_SIZE}. Guardião avançado obrigatório.`);
  } else {
    updateExecutionModeUI();
  }
  try {
    // A própria página do Facebook fica ativa numa janela menor. Um zoom
    // moderado preserva a largura do layout para o editor de compartilhamento.
    const backgroundRequested = proFeature('background_focus') && backgroundMode.checked;
    const advancedProtection = fastPro ? true : (proFeature('advanced_guard') && advancedGuard.checked);
    const panelWindow = await chrome.windows.getCurrent().catch(() => null);
    const width = compact ? 780 : 980;
    const height = compact ? 680 : 720;
    const left = Math.max(screen.availLeft || 0,
      (screen.availLeft || 0) + (screen.availWidth || screen.width) - width - 12);
    const top = (screen.availTop || 0) + 12;
    const workWindow = await chrome.windows.create({url: 'about:blank', type: 'popup',
      focused: !backgroundRequested, width, height, left, top});
    workWindowId = workWindow.id;
    currentWorkWindowId = workWindow.id;
    if (proMonitorAllowed() && proMonitorFacebook) proMonitorFacebook.disabled = false;
    const [tab] = await chrome.tabs.query({windowId: workWindowId});
    if (!tab?.id) throw new Error('Não consegui abrir a janela de trabalho do Facebook.');
    tabId = tab.id;
    if (backgroundRequested && panelWindow?.id) {
      await chrome.windows.update(panelWindow.id, {focused: true}).catch(() => {});
      report('Modo PRO sem foco: a janela de trabalho ficará atrás enquanto o progresso aparece neste painel.');
    }
    report(compact ? 'Janela do Facebook no canto. Mantenha-a aberta durante o teste.' :
      'Janela de trabalho aberta. Mantenha-a aberta e visível durante o teste.');
    async function keepDesktopLayout() {
      if (!compact) return;
      try {
        await chrome.tabs.setZoom(tabId, 0.85);
        const [viewport] = await chrome.scripting.executeScript({target: {tabId},
          func: () => window.innerWidth});
        if ((viewport?.result || 0) >= 840) return;
        throw new Error('largura insuficiente para o editor');
      } catch {
        compact = false;
        await chrome.windows.update(workWindowId, {width: 980, height: 720});
        await chrome.tabs.setZoom(tabId, 0).catch(() => {});
        report('O Facebook precisa de mais espaço: ampliei a janela de trabalho automaticamente.');
      }
    }
    if (mode === 'native') chrome.runtime.onMessage.addListener(progressListener);
    for (let index = 0; index < groups.length && !stopRequested; index++) {
      const group = groups[index];
      currentGroup = group;
      proMonitorSetCurrent(index, groups.length, group, fastPro);
      if (fastPro && batchStatus) {
        const batch = Math.floor(index / FAST_BATCH_SIZE) + 1;
        const batches = Math.ceil(groups.length / FAST_BATCH_SIZE);
        batchStatus.textContent = `⚡ Lote ${batch}/${batches} · grupo ${index + 1}/${groups.length}`;
      }
      if (history.some(item => item.id === group.id && item.hash === messageHash &&
          ['envio acionado', 'aguardando aprovação', 'publicado (confirmação na tela)'].includes(item.status))) {
        updateGroupResult(group.id, 'Já enviado antes — ignorado');
        await markActiveRunResult(group.id, 'já enviado antes — ignorado');
        currentGroup = null;
        finished++;
        progressCount.textContent = `${finished} de ${groups.length} verificados.`;
        continue;
      }
      // A cota é local e contabiliza uma tentativa iniciada, mesmo que o Facebook falhe.
      // Uma fila retomada ignora grupos já enviados antes de gastar uma nova tentativa.
      const fastRequested = fastPro || delay < 30;
      const fastThisGroup = fastRequested && await reserveFastGroup();
      if (fastRequested && !fastThisGroup) {
        report('⚠️ Limite do modo rápido alcançado. Continuando com intervalo mínimo de 30 segundos.');
      }
      updateGroupResult(group.id, mode === 'native' ? 'Confirmando grupo...' : 'Abrindo grupo...');
      report(`Grupo ${index + 1}/${groups.length}: ${mode === 'native' ? 'compartilhando a live com' : 'abrindo'} ${groupNames.get(group.id) || group.id}...`);
      await waitForNavigation(tabId, group.url);
      await safetyCheck(tabId, advancedProtection);
      await keepDesktopLayout();
      if (mode === 'native') {
        const [identity] = await chrome.scripting.executeScript({
          target: {tabId}, func: readGroupIdentity, args: [group.id]
        });
        if (identity?.result?.error || !identity?.result?.name) {
          throw new Error(`${group.id}: ${identity?.result?.error || 'Nome do grupo não encontrado.'}`);
        }
        groupNames.set(group.id, identity.result.name);
        updateGroupResult(group.id, `Grupo confirmado: ${identity.result.name}`);
        report(`${group.id}: nome confirmado como "${identity.result.name}".`);
        const saved = await chrome.storage.local.get('knownGroups');
        const known = Array.isArray(saved.knownGroups) ? saved.knownGroups : [];
        const match = known.find(item => item.id === group.id);
        if (match && match.name !== identity.result.name) {
          match.name = identity.result.name;
          await chrome.storage.local.set({knownGroups: known});
        }
        updateGroupResult(group.id, 'Abrindo live original...');
        await waitForOriginal(tabId, sourceLink);
        await safetyCheck(tabId, advancedProtection);
        await keepDesktopLayout();
      }
      await waitSeconds(3);
      if (stopRequested) break;
      const tabsBeforeShare = mode === 'native' ? new Set((await chrome.tabs.query({})).map(tab => tab.id)) : null;
      const result = await chrome.scripting.executeScript({
        target: {tabId}, func: mode === 'native' ? shareOriginalToGroup : prepareDraft,
        args: mode === 'native' ? [groupNames.get(group.id), progressToken, group.id] : [postText, true, imagePayload]
      });
      const outcome = result[0]?.result;
      report(`${group.id}: ${outcome?.message || outcome || 'Sem resposta do Facebook.'}`);
      let openedOtherTab = false;
      if (mode === 'native' && outcome?.status === 'failed') {
        const extraTabs = (await chrome.tabs.query({})).filter(tab =>
          !tabsBeforeShare.has(tab.id) && /^https:\/\/(?:www\.|m\.)?facebook\.com\//i.test(tab.url || ''));
        openedOtherTab = extraTabs.length > 0;
        if (openedOtherTab) report('O Facebook abriu outra aba durante Compartilhar > Grupo. Confira a aba antes de continuar.');
      }
      const state = outcome?.status === 'ambiguous' ? 'nome ambíguo — ignorado' :
        outcome?.status === 'pending' ? 'aguardando aprovação' :
        outcome?.status === 'blocked' ? 'restrição detectada' :
        outcome?.status === 'published' ? 'publicado (confirmação na tela)' :
        outcome?.status === 'submitted' ? 'envio acionado' : outcome?.status === 'uncertain' ? 'incerto' : 'falhou';
      updateGroupResult(group.id, state);
      finished++;
      progressCount.textContent = `${finished} de ${groups.length} verificados.`;
      await recordResult(group.id, messageHash,
        state);
      currentGroup = null;
      if (outcome?.status === 'ambiguous' ||
          (mode === 'native' && outcome?.status === 'failed' && !openedOtherTab)) {
        skipped++;
        report(`Grupo ${group.id} sem envio confirmado. Seguindo para o próximo grupo após o intervalo.`);
        if (index < groups.length - 1) {
          const interval = await nextGroupInterval(index, groups.length, delay, fastPro);
          if (fastPro && (index + 1) % FAST_BATCH_SIZE === 0) {
            report(`⚡ Lote concluído. Próximo lote após o intervalo configurado de ${interval} segundos.`);
          } else {
            report(`Aguardando ${interval} segundos antes do próximo grupo...`);
          }
          await waitSeconds(interval);
        }
        continue;
      }
      if (!['submitted', 'pending', 'published'].includes(outcome?.status)) {
        report('Fila interrompida para conferir o grupo atual.');
        interrupted = true;
        break;
      }
      if (index < groups.length - 1) {
        const interval = await nextGroupInterval(index, groups.length, delay, fastPro);
        if (fastPro && (index + 1) % FAST_BATCH_SIZE === 0) {
          report(`⚡ Lote concluído. Próximo lote após o intervalo configurado de ${interval} segundos.`);
        } else {
          report(`Aguardando ${interval} segundos antes do próximo grupo...`);
        }
        await waitSeconds(interval);
      }
    }
    if (stopRequested) report('Fila interrompida pelo usuário.');
    else if (interrupted) report('Fila encerrada antes dos demais grupos.');
    else report(`Fila concluída: ${finished} verificados, ${skipped} sem envio nesta execução. Confira as publicações nos grupos.`);
  } catch (error) {
    failed = true;
    const failureText = 'Falha ao abrir: ' + (error.message || error);
    const current = currentGroup || (tabId && groups?.length
      ? groups.find(group => ['Confirmando grupo...', 'Abrindo grupo...', 'Abrindo live original...'].includes(resultRows.get(group.id)?.textContent))
      : null);
    if (current) {
      updateGroupResult(current.id, failureText);
      await recordResult(current.id, messageHash, failureText).catch(() => {});
      currentGroup = null;
    }
    report(`Fila interrompida: ${error.message || error}`);
  } finally {
    const finalRunStatus = stopRequested ? 'stopped' : failed ? 'failed' : interrupted ? 'interrupted' : 'completed';
    await archiveActiveRun(finalRunStatus).catch(() => {});
    if (mode === 'native') chrome.runtime.onMessage.removeListener(progressListener);
    if (workWindowId && !failed && !interrupted && !stopRequested) {
      try { await chrome.windows.remove(workWindowId); } catch { /* janela já fechada */ }
      if (currentWorkWindowId === workWindowId) currentWorkWindowId = null;
    }
    if (proMonitorFacebook && !currentWorkWindowId) proMonitorFacebook.disabled = true;
    if (proMonitorAllowed()) {
      if (stopRequested) proMonitorFinish('Execução parada após o grupo atual.', 'warning');
      else if (failed) proMonitorFinish('Execução interrompida por falha.', 'failed');
      else if (interrupted) proMonitorFinish('Execução interrompida para conferência.', 'warning');
      else proMonitorFinish('Execução concluída.', '');
    }
    running = false;
    stopButton.disabled = true;
    startButton.disabled = false;
    groupsField.disabled = false;
    postField.disabled = false;
    modeField.disabled = false;
    linkField.disabled = false;
    photoField.disabled = false;
    linkPhotoField.disabled = false;
    delayField.disabled = false;
    if (executionMode) executionMode.disabled = !proFeature('queue_250');
    compactWorkWindow.disabled = false;
    applyLicenseUI();
    if (batchStatus) {
      if (fastPro) {
        batchStatus.textContent = failed || interrupted || stopRequested ? '⚡ Rápido PRO · interrompido' : '⚡ Rápido PRO · concluído';
        batchStatus.classList.add('fast');
      } else {
        updateExecutionModeUI();
      }
    }
  }
}

startButton.addEventListener('click', run);
stopButton.addEventListener('click', () => {
  stopRequested = true;
  report('Parada solicitada. Aguardando o grupo atual.');
});
