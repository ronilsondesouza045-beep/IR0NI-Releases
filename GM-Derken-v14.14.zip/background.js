importScripts('client-config.js');
importScripts('auto-reload.js');
'use strict';

const cfg = globalThis.IR0NI_CONFIG || {};
const normalize = value => String(value || '').trim().replace(/\/+$/, '');
const nowIso = () => new Date().toISOString();

const HEARTBEAT_ALARM = 'ironi-heartbeat';
const UPDATER_ALARM = 'gm-derken-updater-check';
const UPDATER_RUNTIME_FILE = 'updater-runtime.json';

function patternFor(url) {
  const u = new URL(url);
  return `${u.protocol}//${u.host}/*`;
}

function versionParts(value) {
  let parts = String(value || '')
    .replace(/^v/i, '')
    .split('.')
    .map(part => Number.parseInt(part, 10) || 0);

  if (parts[0] === 0 && parts.length > 2) {
    parts = parts.slice(1);
  }

  return parts;
}

function newer(latest, current) {
  const a = versionParts(latest);
  const b = versionParts(current);
  const size = Math.max(a.length, b.length);

  for (let i = 0; i < size; i += 1) {
    const x = a[i] || 0;
    const y = b[i] || 0;
    if (x > y) return true;
    if (x < y) return false;
  }

  return false;
}

async function granted(url) {
  try {
    return await chrome.permissions.contains({
      origins: [patternFor(url)]
    });
  } catch {
    return false;
  }
}

async function ensureInstallId() {
  const saved = await chrome.storage.local.get('ironiInstallId');

  if (
    typeof saved.ironiInstallId === 'string' &&
    saved.ironiInstallId.startsWith('IR0NI-')
  ) {
    return saved.ironiInstallId;
  }

  const raw = crypto.randomUUID()
    .replace(/-/g, '')
    .slice(0, 16)
    .toUpperCase();

  const id =
    'IR0NI-' +
    raw.match(/.{1,4}/g).join('-');

  await chrome.storage.local.set({
    ironiInstallId: id
  });

  return id;
}

async function setOffline(reason) {
  const previous = (
    await chrome.storage.local.get('ironiOnlineState')
  ).ironiOnlineState || {};

  const state = {
    ...previous,
    ok: false,
    connected: false,
    reason: String(
      reason || 'Servidor indisponível.'
    ),
    checked_at: nowIso()
  };

  await chrome.storage.local.set({
    ironiOnlineState: state
  });

  return state;
}

async function heartbeat(force = false) {
  const server = normalize(cfg.serverUrl);

  if (!server) {
    return setOffline(
      'Servidor GM Derken ainda não configurado.'
    );
  }

  if (!await granted(server)) {
    return setOffline(
      'A conexão com o servidor ainda não foi autorizada neste Chrome.'
    );
  }

  const data = await chrome.storage.local.get([
    'ironiInstallId',
    'ironiLicenseToken',
    'ironiOnlineState'
  ]);

  const installId =
    data.ironiInstallId ||
    await ensureInstallId();

  const previous =
    data.ironiOnlineState || {};

  if (
    !force &&
    previous.checked_at &&
    Date.now() -
      Date.parse(previous.checked_at) <
      45000
  ) {
    return previous;
  }

  try {
    const controller =
      new AbortController();

    const timer =
      setTimeout(
        () => controller.abort(),
        12000
      );

    const response = await fetch(
      `${server}/api/client/heartbeat`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        signal: controller.signal,
        body: JSON.stringify({
          install_id: installId,
          version:
            chrome.runtime.getManifest().version,
          license_token:
            data.ironiLicenseToken || ''
        })
      }
    );

    clearTimeout(timer);

    if (!response.ok) {
      throw new Error(
        `HTTP ${response.status}`
      );
    }

    const json =
      await response.json();

    const state = {
      ...json,
      ok: true,
      connected: true,
      checked_at: nowIso()
    };

    await chrome.storage.local.set({
      ironiOnlineState: state
    });

    return state;

  } catch (error) {
    return setOffline(
      error?.name === 'AbortError'
        ? 'Tempo esgotado ao conectar ao servidor.'
        : (error?.message || error)
    );
  }
}

async function readUpdaterRuntime() {
  const current =
    chrome.runtime.getManifest().version;

  let state;

  try {
    const response = await fetch(
      chrome.runtime.getURL(
        `${UPDATER_RUNTIME_FILE}?t=${Date.now()}`
      ),
      {
        cache: 'no-store'
      }
    );

    if (!response.ok) {
      throw new Error(
        `HTTP ${response.status}`
      );
    }

    const runtime =
      await response.json();

    state = {
      helperInstalled: true,
      helperVersion:
        String(runtime.helper_version || ''),
      status:
        String(runtime.status || 'active'),
      lastCheck:
        String(runtime.last_check || ''),
      currentVersion:
        String(
          runtime.current_version || current
        ),
      installedVersion:
        String(
          runtime.installed_version || ''
        ),
      message:
        String(runtime.message || '')
    };

  } catch {
    const saved = await chrome.storage.local.get([
      'gmDerkenUpdaterState',
      'gmDerkenAutoUpdateState'
    ]);

    const previous = saved.gmDerkenUpdaterState || {};
    const automatic = saved.gmDerkenAutoUpdateState || {};
    const knownInstalled = Boolean(previous.helperInstalled);

    state = {
      helperInstalled: knownInstalled,
      helperVersion: String(previous.helperVersion || ''),
      status: knownInstalled
        ? String(automatic.status || previous.status || 'active')
        : 'detecting',
      lastCheck: String(automatic.lastCheck || previous.lastCheck || ''),
      currentVersion: current,
      installedVersion: String(previous.installedVersion || current),
      message: knownInstalled
        ? String(automatic.message || previous.message || 'Atualização automática ativa.')
        : 'Canal automático ativo. Confirmando o helper local...'
    };
  }

  await chrome.storage.local.set({
    gmDerkenUpdaterState: state
  });

  if (
    state.helperInstalled &&
    state.installedVersion &&
    newer(
      state.installedVersion,
      current
    )
  ) {
    await chrome.storage.local.set({
      gmDerkenUpdaterState: {
        ...state,
        status: 'reloading',
        message:
          `Atualização ${state.installedVersion} instalada. Recarregando a extensão...`
      }
    });

    setTimeout(
      () => chrome.runtime.reload(),
      1200
    );
  }

  return state;
}

async function schedule() {
  const minutes =
    Math.max(
      1,
      Number(cfg.heartbeatMinutes) || 1
    );

  await chrome.alarms.clear(
    HEARTBEAT_ALARM
  );

  await chrome.alarms.clear(
    UPDATER_ALARM
  );

  chrome.alarms.create(
    HEARTBEAT_ALARM,
    {
      periodInMinutes: minutes
    }
  );

  chrome.alarms.create(
    UPDATER_ALARM,
    {
      periodInMinutes: 1
    }
  );
}

chrome.runtime.onInstalled.addListener(
  () => {
    ensureInstallId();
    schedule();
    heartbeat(true);
    readUpdaterRuntime();
  }
);

chrome.runtime.onStartup.addListener(
  () => {
    schedule();
    heartbeat(true);
    readUpdaterRuntime();
  }
);

chrome.alarms.onAlarm.addListener(
  alarm => {
    if (alarm.name === HEARTBEAT_ALARM) {
      heartbeat(false);
    }

    if (alarm.name === UPDATER_ALARM) {
      readUpdaterRuntime();
    }
  }
);

chrome.runtime.onMessage.addListener(
  (msg, _sender, sendResponse) => {

    if (msg?.type === 'ironi:heartbeat') {
      heartbeat(Boolean(msg.force))
        .then(sendResponse);
      return true;
    }

    if (msg?.type === 'ironi:online-state') {
      chrome.storage.local
        .get('ironiOnlineState')
        .then(value =>
          sendResponse(
            value.ironiOnlineState || {}
          )
        );
      return true;
    }

    if (
      msg?.type ===
      'gmderken:updater-state'
    ) {
      readUpdaterRuntime()
        .then(sendResponse);
      return true;
    }
  }
);

schedule();
ensureInstallId()
  .then(() => heartbeat(true))
  .catch(() => {});

readUpdaterRuntime()
  .catch(() => {});
