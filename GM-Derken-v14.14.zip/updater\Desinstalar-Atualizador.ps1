﻿$ErrorActionPreference = "SilentlyContinue"

$InstallDir =
    Join-Path `
        $env:LOCALAPPDATA `
        "GM-Derken-Updater"

$ConfigPath =
    Join-Path `
        $InstallDir `
        "config.json"

$ExtensionPath = ""

if(Test-Path $ConfigPath) {
    try {
        $Config =
            Get-Content $ConfigPath -Raw |
            ConvertFrom-Json

        $ExtensionPath =
            [string]$Config.extension_path
    }
    catch {}
}

Get-CimInstance Win32_Process |
Where-Object {
    $_.CommandLine -and
    $_.CommandLine -like "*GM-Derken-Updater.ps1*"
} |
ForEach-Object {
    Stop-Process `
        -Id $_.ProcessId `
        -Force `
        -ErrorAction SilentlyContinue
}

$RunKey =
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"

Remove-ItemProperty `
    -Path $RunKey `
    -Name "GM Derken Updater" `
    -ErrorAction SilentlyContinue

if(
    $ExtensionPath -and
    (Test-Path $ExtensionPath)
) {
    Remove-Item `
        (Join-Path $ExtensionPath "updater-runtime.json") `
        -Force `
        -ErrorAction SilentlyContinue
}

if(Test-Path $InstallDir) {
    Remove-Item `
        $InstallDir `
        -Recurse `
        -Force
}

Write-Host "Atualizador GM Derken removido."
