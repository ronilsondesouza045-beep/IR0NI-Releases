(() => {
  'use strict';
  const PUBLIC_JWK = {
    kty: 'EC', crv: 'P-256',
    x: 'Q2Qo2oMArMR0de-U-EH3XOnO6d4OjAVO5OrEQQkO_b4',
    y: 'cpVcXO0aatIy3toUepEMgF2g4-PIFWTZAMKemogllA8',
    ext: true, key_ops: ['verify']
  };
  const PREFIX = 'IR0NI1';
  const DEFAULT_FEATURES = ['queue_250','native_share','background_focus','campaign_presets','history_export','panel_art','advanced_guard'];
  const GRACE_HOURS = Number(globalThis.IR0NI_CONFIG?.onlineGraceHours || 6);
  function b64urlToBytes(value) { const n=value.replace(/-/g,'+').replace(/_/g,'/'); const p=n+'='.repeat((4-n.length%4)%4); const raw=atob(p); return Uint8Array.from(raw,ch=>ch.charCodeAt(0)); }
  function bytesToText(bytes) { return new TextDecoder().decode(bytes); }
  function shortId(uuid) { return 'IR0NI-'+uuid.replace(/-/g,'').slice(0,16).toUpperCase().match(/.{1,4}/g).join('-'); }
  async function getInstallId() { const s=await chrome.storage.local.get('ironiInstallId'); if(typeof s.ironiInstallId==='string'&&/^IR0NI-[A-F0-9-]{19}$/.test(s.ironiInstallId)) return s.ironiInstallId; const id=shortId(crypto.randomUUID()); await chrome.storage.local.set({ironiInstallId:id}); return id; }
  async function getToken() { const s=await chrome.storage.local.get('ironiLicenseToken'); return String(s.ironiLicenseToken||''); }
  async function verifyToken(token, applyOnline=true) {
    const installId=await getInstallId();
    if(typeof token!=='string'||!token.trim()) return {valid:false,reason:'Nenhuma licença salva.',installId};
    const parts=token.trim().split('.'); if(parts.length!==3||parts[0]!==PREFIX) return {valid:false,reason:'Formato da licença inválido.',installId};
    try {
      const payloadBytes=b64urlToBytes(parts[1]), signature=b64urlToBytes(parts[2]); const payload=JSON.parse(bytesToText(payloadBytes));
      const key=await crypto.subtle.importKey('jwk',PUBLIC_JWK,{name:'ECDSA',namedCurve:'P-256'},false,['verify']);
      const signedText=new TextEncoder().encode(`${parts[0]}.${parts[1]}`);
      const ok=await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},key,signature,signedText);
      if(!ok) return {valid:false,reason:'Assinatura da licença inválida.',installId};
      if(payload.iss!=='IR0NI'||payload.plan!=='PRO') return {valid:false,reason:'Plano da licença não reconhecido.',installId};
      if(payload.install_id!==installId) return {valid:false,reason:'Esta licença pertence a outra instalação.',installId};
      const expiresAt=Date.parse(payload.expires_at||''); if(!Number.isFinite(expiresAt)||Date.now()>=expiresAt) return {valid:false,reason:'Licença PRO expirada.',installId,payload};
      const features=Array.isArray(payload.features)?payload.features.filter(x=>typeof x==='string'):DEFAULT_FEATURES;
      const base={valid:true,plan:'PRO',installId,payload:{...payload,features},expiresAt};
      if(!applyOnline||!payload.online_required) return base;
      const saved=await chrome.storage.local.get('ironiOnlineState'); const online=saved.ironiOnlineState||{};
      if(online?.license?.revoked||online?.license?.status==='revoked') return {...base,valid:false,reason:'Licença PRO revogada pelo administrador.',online};
      if(online?.license?.valid===false&&online?.connected) return {...base,valid:false,reason:online.license.reason||'Licença recusada pelo servidor.',online};
      const lastGood=Date.parse(online?.license?.last_validated_at||online?.last_validated_at||'');
      if(Number.isFinite(lastGood)&&Date.now()-lastGood<=GRACE_HOURS*3600000) return {...base,onlineValidated:true,online};
      return {...base,valid:false,reason:`Conecte ao servidor GM Derken para validar o PRO. Tolerância offline: ${GRACE_HOURS}h.`,online};
    } catch(error) { return {valid:false,reason:'Não foi possível validar a licença.',installId,error:String(error?.message||error)}; }
  }
  async function getState() { return verifyToken(await getToken(),true); }
  async function activate(token) { const state=await verifyToken(token,false); if(!state.valid) return state; await chrome.storage.local.set({ironiLicenseToken:token.trim()}); return state; }
  async function deactivate() { await chrome.storage.local.remove('ironiLicenseToken'); return getState(); }
  function hasFeature(state,feature) { return Boolean(state?.valid&&state?.payload?.features?.includes(feature)); }
  globalThis.IR0NILicense={getInstallId,getToken,getState,verifyToken,activate,deactivate,hasFeature,DEFAULT_FEATURES};
})();
