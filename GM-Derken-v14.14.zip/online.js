(() => {
  'use strict';
  const cfg = globalThis.IR0NI_CONFIG || {};
  const normalize = value => String(value || '').trim().replace(/\/+$/, '');
  const serverUrl = () => normalize(cfg.serverUrl);
  function originPattern(url) {
    const u = new URL(url);
    return `${u.protocol}//${u.host}/*`;
  }
  async function hasPermission() {
    const url = serverUrl();
    if (!url) return false;
    try { return await chrome.permissions.contains({origins:[originPattern(url)]}); }
    catch { return false; }
  }
  async function connect() {
    const url = serverUrl();
    if (!url) return {ok:false, reason:'Servidor GM Derken ainda não foi configurado pelo administrador.'};
    let allowed = await hasPermission();
    if (!allowed) allowed = await chrome.permissions.request({origins:[originPattern(url)]});
    if (!allowed) return {ok:false, reason:'Permissão para conectar ao servidor não foi concedida.'};
    const result = await chrome.runtime.sendMessage({type:'ironi:heartbeat', force:true});
    return result || {ok:false, reason:'Servidor sem resposta.'};
  }
  async function heartbeat() {
    return chrome.runtime.sendMessage({type:'ironi:heartbeat', force:true});
  }
  async function getState() {
    const saved = await chrome.storage.local.get('ironiOnlineState');
    return saved.ironiOnlineState || {ok:false, connected:false};
  }
  async function openUpdate() {
    const state = await getState();
    const url = state?.update?.download_url || state?.update?.html_url;
    if (!url) return false;
    await chrome.tabs.create({url}); return true;
  }
  globalThis.IR0NIOnline = {serverUrl, hasPermission, connect, heartbeat, getState, openUpdate};
})();
