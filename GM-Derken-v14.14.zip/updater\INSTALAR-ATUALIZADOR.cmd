@echo off
title GM Derken - Instalar Atualizador
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar-Atualizador.ps1"
echo.
pause
