(() => {
  'use strict';

  document.title = 'GM Derken';

  const hero =
    document.getElementById('gm-derken-hero');

  if (hero) {
    hero.setAttribute(
      'aria-label',
      'GM Derken · Divulgação WoW 3.3.5a'
    );
  }
})();
